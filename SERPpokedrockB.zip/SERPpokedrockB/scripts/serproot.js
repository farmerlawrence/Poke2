import{Player,Entity,EntityHealthComponent,EntityInventoryComponent,ItemDurabilityComponent,ItemStack,Dimension,ScoreboardObjective,Vector,world,system}from"@minecraft/server";
import{ActionFormData,ModalFormData}from"@minecraft/server-ui";
var vit=0;var box=0;var select=0;var traded1="0";var traded2="0";
function getRadius(player,x,y,z,radius){const playerLocation=player.location;const playerX=playerLocation.x;const playerY=playerLocation.y;const playerZ=playerLocation.z;const distanceSquared=(playerX-x)**2+(playerY-y)**2+(playerZ-z)**2;const radiusSquared=radius**2;if(distanceSquared<=radiusSquared){return true;}else{return false;}}
function getFrom(vector){return Math.sqrt(vector.x*vector.x+vector.y*vector.y+vector.z*vector.z);}
function getDistance(posA,posB){let direction={x:posA.x-posB.x,y:posA.y-posB.y,z:posA.z-posB.z};return getFrom(direction);}
const ScoreboardAction={add:"add",remove:"remove",set:"set"};
function getScore(objectiveId,player){return world.scoreboard.getObjective(objectiveId).getScore(player.scoreboardIdentity);};
function setScore(entity,objectiveId,score, action){const objective=world.scoreboard.getObjective(objectiveId);if(!objective)throw new ReferenceError('Scoreboard objective does not exist in world.');const previousScore=!!entity.scoreboardIdentity?objective.getScore(entity.scoreboardIdentity):0;switch(action){case ScoreboardAction.add:score+=previousScore;break;case ScoreboardAction.remove:score-=previousScore;break;default:break;}if(!entity.scoreboardIdentity)entity.runCommand('scoreboard players set @s '+objective+' '+score);else {objective.setScore(entity.scoreboardIdentity, score);}};
function setScoreR(min,max){return Math.floor(Math.random()*(max-min+1))+min;}
function getRandom(arr){const randomIndex=Math.floor(Math.random()*arr.length);const item=arr[randomIndex];return item;};
const trainers=[{TrainerId:[1,3,5,8,9,10,49,50,51,52]},{Tid:[1],cusmn:50,pk1:[10,19,21,23,27,43,161,163,167,177,179,206,216,231,261,263,265,270,273,276,287,293,304,311,312,316],pk2:[11,20,22,24,27,162,164,168,178,180,216,231,261,263,265,270,273,276,288,294,305,316],pk3:[12,20,22,24,28,45,162,164,168,178,181,217,232,262,264,271,274,277,289,295,306,317]},{Tid:[3],cusmn:1000,pk1:[1,4,7,27,29,32,46,50,52,58,69,72],pk2:[2,5,8,27,30,33,46,50,52,58,70,72],pk3:[3,6,9,28,31,34,47,51,53,59,71,73]},{Tid:[4],cusmn:150,pk1:[43,46,60,58,81,100,133,165,177,190,238,239,240],pk2:[44,46,58,82,100,114,133,165,177,238,239,240],pk3:[44,47,59,82,101,114,122,124,125,126,134,135,136,166,178,196,197]},{Tid:[5],cusmn:100,pk1:[1,10,16,19,21,23,27,29,32,35,37,39,43,46,50,52,72,77,86,116,118,172,177,183,187,190,263,265,270],pk2:[2,11,17,19,21,23,25,27,30,33,35,37,39,44,46,50,52,72,77,86,114,116,118,177,183,188,190,263,266,268,271],pk3:[3,12,18,20,22,24,26,28,31,34,36,38,40,45,47,51,53,73,78,87,114,117,119,178,184,189,264,267,269,272]},{Tid:[6],cusmn:100,pk1:[19,25,60,66,72,90,98,116,118,120,158,170,223,298],pk2:[19,25,61,67,72,90,98,116,118,120,159,170,183,223],pk3:[20,26,62,68,73,91,99,117,119,121,160,171,184,186,224]},{Tid:[7],cusmn:100,pk1:[10,13,46,48,165,193,204,214,265,283,290],pk2:[11,14,46,48,165,167,193,213,214,266,268,283,291,292],pk3:[12,15,47,49,166,168,212,214,267,269,284,291,292]},{Tid:[50],cusmn:450,pk1:[19,27,29,32,41,43,48,66,88,104,109,167,193,200,201,211,223,261,263,276,290,302,303,316],pk2:[19,27,30,33,41,44,48,67,88,104,109,167,193,200,201,211,223,261,263,276,291,292,302,303,316],pk3:[20,28,31,34,42,45,49,68,89,105,110,168,193,200,201,212,224,262,264,277,291,292,302,303,317]}];
const attacks=[{Aid:0,icon:"null"},{Aid:1,type:1,icon:"bug",power:40,precision:95,class:"physical"},{Aid:2,type:1,icon:"bug",power:50,precision:100,class:"physical"},{Aid:3,type:1,icon:"bug",power:120,precision:85,class:"physical"},{Aid:11,type:1,icon:"bug",power:50,precision:100,class:"special"},{Aid:12,type:1,icon:"bug",power:60,precision:100,class:"special"},{Aid:13,type:1,icon:"bug",power:90,precision:100,class:"special"},{Aid:21,type:2,icon:"dark",power:60,precision:100,class:"physical"},{Aid:22,type:2,icon:"dark",power:65,precision:100,class:"physical"},{Aid:23,type:2,icon:"dark",power:70,precision:100,class:"physical"},{Aid:31,type:2,icon:"dark",power:55,precision:95,class:"special"},{Aid:32,type:2,icon:"dark",power:80,precision:100,class:"special"},{Aid:33,type:2,icon:"dark",power:85,precision:95,class:"special"},{Aid:41,type:3,icon:"dragon",power:60,precision:100,class:"physical"},{Aid:42,type:3,icon:"dragon",power:80,precision:100,class:"physical"},{Aid:43,type:3,icon:"dragon",power:120,precision:100,class:"physical"},{Aid:51,type:3,icon:"dragon",power:40,precision:100,class:"special"},{Aid:52,type:3,icon:"dragon",power:60,precision:100,class:"special"},{Aid:53,type:3,icon:"dragon",power:130,precision:90,class:"special"},{Aid:61,type:4,icon:"electric",power:65,precision:95,class:"physical"},{Aid:62,type:4,icon:"electric",power:75,precision:100,class:"physical"},{Aid:63,type:4,icon:"electric",power:90,precision:100,class:"physical"},{Aid:71,type:4,icon:"electric",power:40,precision:100,class:"special"},{Aid:72,type:4,icon:"electric",power:90,precision:100,class:"special"},{Aid:73,type:4,icon:"electric",power:110,precision:70,class:"special"},{Aid:81,type:5,icon:"fairy",power:90,precision:90,class:"physical"},{Aid:82,type:5,icon:"fairy",power:65,precision:100,class:"physical"},{Aid:83,type:5,icon:"fairy",power:70,precision:100,class:"physical"},{Aid:91,type:5,icon:"fairy",power:50,precision:100,class:"special"},{Aid:92,type:5,icon:"fairy",power:80,precision:100,class:"special"},{Aid:93,type:5,icon:"fairy",power:95,precision:100,class:"special"},{Aid:101,type:6,icon:"fighting",power:50,precision:100,class:"physical"},{Aid:102,type:6,icon:"fighting",power:85,precision:90,class:"physical"},{Aid:103,type:6,icon:"fighting",power:120,precision:100,class:"physical"},{Aid:111,type:6,icon:"fighting",power:40,precision:100,class:"special"},{Aid:112,type:6,icon:"fighting",power:80,precision:100,class:"special"},{Aid:113,type:6,icon:"fighting",power:120,precision:70,class:"special"},{Aid:121,type:7,icon:"fire",power:50,precision:100,class:"physical"},{Aid:122,type:7,icon:"fire",power:75,precision:100,class:"physical"},{Aid:123,type:7,icon:"fire",power:120,precision:100,class:"physical"},{Aid:131,type:7,icon:"fire",power:50,precision:100,class:"special"},{Aid:132,type:7,icon:"fire",power:90,precision:100,class:"special"},{Aid:133,type:7,icon:"fire",power:110,precision:85,class:"special"},{Aid:141,type:8,icon:"flying",power:35,precision:100,class:"physical"},{Aid:142,type:8,icon:"flying",power:55,precision:100,class:"physical"},{Aid:143,type:8,icon:"flying",power:60,precision:100,class:"physical"},{Aid:151,type:8,icon:"flying",power:40,precision:100,class:"special"},{Aid:152,type:8,icon:"flying",power:60,precision:95,class:"special"},{Aid:153,type:8,icon:"flying",power:110,precision:70,class:"special"},{Aid:161,type:9,icon:"ghost",power:30,precision:100,class:"physical"},{Aid:162,type:9,icon:"ghost",power:40,precision:100,class:"physical"},{Aid:163,type:9,icon:"ghost",power:70,precision:100,class:"physical"},{Aid:171,type:9,icon:"ghost",power:60,precision:100,class:"special"},{Aid:172,type:9,icon:"ghost",power:65,precision:100,class:"special"},{Aid:173,type:9,icon:"ghost",power:80,precision:100,class:"special"},{Aid:181,type:10,icon:"grass",power:40,precision:100,class:"physical"},{Aid:182,type:10,icon:"grass",power:55,precision:95,class:"physical"},{Aid:183,type:10,icon:"grass",power:90,precision:100,class:"physical"},{Aid:191,type:10,icon:"grass",power:20,precision:100,class:"special",effect:191},{Aid:192,type:10,icon:"grass",power:65,precision:90,class:"special"},{Aid:193,type:10,icon:"grass",power:90,precision:95,class:"special"},{Aid:201,type:11,icon:"ground",power:60,precision:100,class:"physical"},{Aid:202,type:11,icon:"ground",power:95,precision:95,class:"physical"},{Aid:203,type:11,icon:"ground",power:100,precision:100,class:"physical"},{Aid:211,type:11,icon:"ground",power:20,precision:95,class:"special"},{Aid:212,type:11,icon:"ground",power:55,precision:95,class:"special"},{Aid:213,type:11,icon:"ground",power:95,precision:85,class:"special"},{Aid:221,type:12,icon:"ice",power:40,precision:100,class:"physical"},{Aid:222,type:12,icon:"ice",power:65,precision:95,class:"physical"},{Aid:223,type:12,icon:"ice",power:75,precision:100,class:"physical"},{Aid:231,type:12,icon:"ice",power:40,precision:100,class:"special"},{Aid:232,type:12,icon:"ice",power:55,precision:95,class:"special"},{Aid:233,type:12,icon:"ice",power:90,precision:100,class:"special"},{Aid:241,type:13,icon:"normal",power:40,precision:100,class:"physical"},{Aid:242,type:13,icon:"normal",power:40,precision:100,class:"physical"},{Aid:243,type:13,icon:"normal",power:40,precision:100,class:"physical"},{Aid:244,type:13,icon:"normal",power:60,precision:100,class:"physical"},{Aid:245,type:13,icon:"normal",power:100,precision:100,class:"physical"},{Aid:251,type:13,icon:"normal",power:40,precision:100,class:"special"},{Aid:252,type:13,icon:"normal",power:60,precision:100,class:"special"},{Aid:253,type:13,icon:"normal",power:150,precision:90,class:"special"},{Aid:256,type:13,icon:"normal",precision:100,class:"status"},{Aid:257,type:13,icon:"normal",precision:100,class:"status"},{Aid:261,type:14,icon:"poison",power:50,precision:100,class:"physical"},{Aid:262,type:14,icon:"poison",power:80,precision:100,class:"physical"},{Aid:263,type:14,icon:"poison",power:120,precision:80,class:"physical"},{Aid:271,type:14,icon:"poison",power:40,precision:100,class:"special"},{Aid:272,type:14,icon:"poison",power:65,precision:100,class:"special"},{Aid:273,type:14,icon:"poison",power:90,precision:100,class:"special"},{Aid:274,type:14,icon:"poison",precision:90,class:"status"},{Aid:281,type:15,icon:"psychic",power:70,precision:100,class:"physical"},{Aid:282,type:15,icon:"psychic",power:80,precision:90,class:"physical"},{Aid:283,type:15,icon:"psychic",power:70,precision:100,class:"physical"},{Aid:291,type:15,icon:"psychic",power:50,precision:100,class:"special"},{Aid:292,type:15,icon:"psychic",power:90,precision:100,class:"special"},{Aid:293,type:15,icon:"psychic",precision:60,class:"status"},{Aid:301,type:16,icon:"rock",power:50,precision:90,class:"physical"},{Aid:302,type:16,icon:"rock",power:60,precision:95,class:"physical"},{Aid:303,type:16,icon:"rock",power:100,precision:80,class:"physical"},{Aid:311,type:16,icon:"rock",power:60,precision:100,class:"special"},{Aid:312,type:16,icon:"rock",power:120,precision:90,class:"special"},{Aid:313,type:16,icon:"rock",power:80,precision:100,class:"special"},{Aid:321,type:17,icon:"steel",power:50,precision:95,class:"physical"},{Aid:322,type:17,icon:"steel",power:70,precision:100,class:"physical"},{Aid:323,type:17,icon:"steel",power:100,precision:75,class:"physical"},{Aid:331,type:17,icon:"steel",power:65,precision:85,class:"special"},{Aid:332,type:17,icon:"steel",power:80,precision:100,class:"special"},{Aid:333,type:17,icon:"steel",power:140,precision:95,class:"special"},{Aid:341,type:18,icon:"water",power:40,precision:100,class:"physical"},{Aid:342,type:18,icon:"water",power:80,precision:100,class:"physical"},{Aid:343,type:18,icon:"water",power:90,precision:90,class:"physical"},{Aid:351,type:18,icon:"water",power:40,precision:100,class:"special"},{Aid:352,type:18,icon:"water",power:60,precision:100,class:"special"},{Aid:353,type:18,icon:"water",power:110,precision:80,class:"special"}
];
system.runInterval(()=>{
Array.from(world.getDimension('overworld').getEntities()).forEach(entity=>{let hp=entity.getComponent('health');
    if(entity.typeId.startsWith("pokemon:")){
    if(entity.getComponent("minecraft:can_fly")){if(!entity.isOnGround&&!entity.isInWater){entity.getComponent("minecraft:movement").setCurrentValue(0.3);entity.runCommand("effect @s slow_falling 1 3 true");}else{entity.getComponent("minecraft:movement").setCurrentValue(0.1);}}
    if(entity.hasTag("tamed")&&(!entity.hasTag("defeated"))){entity.vit++;entity.runCommand("function wild/pokecons");if(entity.vit>=10){entity.runCommand(`function pokemon/${entity.typeId.replace('pokemon:p','')}`);entity.vit=0}}
    if(!entity.hasTag("defeated")&&!entity.hasTag("called")&&!entity.hasTag("evolving")){entity.runCommand(`scoreboard players set @s HPserpC ${hp.currentValue}`);}
    if(entity.hasTag("evolving")||entity.hasTag("from_trainer")||entity.hasTag("evolved")||entity.hasTag("defeated")||entity.hasTag("battle")){entity.runCommand("effect @s slowness 1 10 true");if(entity.hasTag("defeated")){setScore(entity,"HPserpC",1);}}
    if(getScore('HPserpC',entity)==1&&!entity.hasTag("defeated")){entity.triggerEvent("serp:defeated");}
    if(entity.hasTag("battle")){battle(entity)}
    }
    if(entity.hasTag("summoning")){if(entity.typeId==="serp:hoopa_ring"){if(!entity.hasTag("legendary")){entity.runCommand(`summon pokemon:p${Math.floor((Math.random()*386)+1)} ~~1.5~`)}else{entity.runCommand(`summon pokemon:p${getScore("entityserp",entity)} ~~1.5~`)}entity.triggerEvent("serp:despawn");};if(entity.typeId==="serp:trainer"){for(const trainer of trainers){if(getScore("TrainerID",entity)==trainer.Tid){if(getScore("exp",entity)>0&&getScore("exp",entity)<=1000){entity.runCommand(`summon pokemon:p${getRandom(trainer.pk1)} ^^^0.5`);}else if(getScore("exp",entity)>1000&&getScore("exp",entity)<=1750){entity.runCommand(`summon pokemon:p${getRandom(trainer.pk2)} ^^^0.5`);}else if(getScore("exp",entity)>1750){entity.runCommand(`summon pokemon:p${getRandom(trainer.pk3)} ^^^0.5`);}entity.runCommand("tag @e[family=pokemon,c=1,tag=!tamed] add from_trainer");entity.runCommand(`scoreboard players operation @e[family=pokemon,c=1,tag=from_trainer] VICT = @s VICT`);entity.runCommand(`scoreboard players set @e[family=pokemon,c=1,tag=from_trainer] exp ${getScore("exp",entity)+setScoreR(-250,250)}`);entity.removeTag("summoning");}}}}
    if(entity.typeId==="serp:trade_machine"&&getScore("mount",entity)>0){Array.from(world.getPlayers()).forEach(player=>{if(getScore("mount",player)==getScore("mount",entity)&&(!player.hasTag("summary"))){entity.triggerEvent("serp:reset");}});}
    });
Array.from(world.getPlayers()).forEach(player=>{
  if(player.hasTag("evolve")){player.runCommand("effect @s resistance 1 99 true");}
  if(getScore("entityserp",player)>0){getPokemon(player);}
  if(!player.hasTag("started")){player.getTags().forEach(tag=>{if(tag.includes("stg")){player.removeTag(tag);}if(tag.includes("team")){player.removeTag(tag);}if(tag.includes("max_vial")){player.removeTag(tag);}});if(player.hasTag("gen1")||player.hasTag("gen2")||player.hasTag("gen3")){forms.start1(player);player.addTag("started");}else if(!player.hasTag("gen1")&&!player.hasTag("gen2")&&!player.hasTag("gen3")){player.runCommand('titleraw @s actionbar{"rawtext":[{"translate":"serp.set_gens"}]}');}}
  if(getScore("mount",player)>0&&(!player.hasTag("summary"))){if(player.hasTag(`use_slot${player.select}`)){player.removeTag(`use_slot${player.select}`)};player.select=0;if(player.hasTag("trader1")){player.removeTag("trader1");}if(player.hasTag("trader2")){player.removeTag("trader2");}player.playSound("serp.market.store");setScore(player,"mount",0);}
  if(getScore("VICN",player)>0){player.runCommand(`execute as @s unless entity @e[type=serp:trainer,scores={VICN=${getScore("VICN",player)}}] run scoreboard players set @s VICN 0`)}
  slotc(player);
  bound(player);
});
});
world.beforeEvents.itemUse.subscribe(pmenu=>{
let item=pmenu.itemStack;let player=pmenu.source;
  if((item.typeId=="minecraft:compass")&&!player.hasTag("evolve")&&(!player.hasTag("summary"))){system.run(()=>forms.main(player));system.run(()=>player.addTag("summary"));system.run(()=>player.runCommand("summon serp:dialogue"));if(player.hasTag("gen1")){system.run(()=>player.removeTag("gen1"));}if(player.hasTag("gen2")){system.run(()=>player.removeTag("gen2"));}if(player.hasTag("gen3")){system.run(()=>player.removeTag("gen3"));}}
});
world.afterEvents.dataDrivenEntityTriggerEvent.subscribe((event)=>{
let s=event.entity;let hp=s.getComponent('health');let caller=s.nameTag;let nick="0";let slot="0";
    switch(event.eventId){
    case("serp:clear"):{s.getTags().forEach(tag=>{if(tag.includes("use_slot")){slot=tag.replace('use_slot','');}});s.getTags().forEach(tag=>{if(tag.startsWith(`team${slot}/`)){if(tag.split("/")[18]==="0"){nick='entity.pokemon:p'+getScore(`team${slot}`,s)+'.name';}else{nick=tag.split("/")[18].replace("nickname&","");}}});s.runCommand("event entity @e[type=serp:spawn,c=1] serp:s"+getScore(`team${slot}`,s));s.runCommand(`titleraw @s actionbar{"rawtext":[{"translate":"serp.choose_you"},{"translate":"${nick}"},{"text":"!"}]}`);s.playSound("mob.pokemon."+getScore(`team${slot}`,s));};break;
    case("serp:on_spawn"):{s.getTags().forEach(tag=>{if(tag.includes("SMN")){slot=tag.replace('SMN','');}});s.runCommand(`tag @e[tag=called,c=1] add "owner&${caller}&${slot}"`);s.runCommand(`tag @e[tag="owner&${caller}&${slot}"] remove called`);s.getTags().forEach(tag=>{if(tag.startsWith(`team${slot}/`)){let part=tag.split("/");let sc=`scoreboard players set @e [tag="owner&${caller}&${slot}"] `;s.runCommand(sc+"ball "+part[1]);s.runCommand(sc+"subspc "+part[4]);s.runCommand(sc+"HPserpC "+part[5]);s.runCommand(sc+"condition "+part[6]);s.runCommand(sc+"amistadserp "+part[7]);s.runCommand(sc+"exp "+part[8]);s.runCommand(sc+"naturaleza "+part[9]);s.runCommand(sc+"ability "+part[10]);s.runCommand(sc+"item "+part[11]);s.runCommand(sc+"gigamaxf "+part[12]);s.runCommand(sc+"dynamaxl "+part[13]);s.runCommand(sc+"attack1 "+part[14]);s.runCommand(sc+"attack2 "+part[15]);s.runCommand(sc+"attack3 "+part[16]);s.runCommand(sc+"attack4 "+part[17]);if(part[18]!=="0"){s.runCommand(`tag @e[tag="owner&${caller}&${slot}"] add "${part[18]}"`);}if(part[4]!=="0"){s.runCommand(`event entity @e[tag="owner&${caller}&${slot}"] serp:s${part[4]}`)};s.runCommand(`event entity @e[tag="owner&${caller}&${slot}"] serp:v${part[3]}`);}});s.addTag(`out_slot${slot}`);s.removeTag(`SMN${slot}`);s.removeTag("summary");};break;
    case("minecraft:entity_spawned"):{if(s.typeId.startsWith("pokemon:")&&(!s.hasTag("evolved"))){s.runCommand("function wild/spawn");}else if(s.typeId==="serp:trainer"){for(const trainer of trainers){if(trainer.TrainerId){s.triggerEvent(`serp:trainer${getRandom(trainer.TrainerId)*1}`);}}s.runCommand(`scoreboard players random @s VICN 1 9999`);s.runCommand(`scoreboard players random @s VICT 1 9999`);}};break;
    case("minecraft:entity_transformed"):{s.vit=0;if(s.typeId.startsWith("pokemon:")){s.addTag("called");s.addTag("tamed");s.runCommand("event entity @p serp:on_spawn");}};break;
    case("serp:evolve"):{s.addTag("evolving");setScore(s,"STGC2",130);s.runCommand("effect @s resistance 20 20 true");};break;
    case("serp:despawn"):{
    if(s.hasTag("evolving")){const sc="scoreboard players set @e[family=pokemon,c=1,tag=evolved] ";s.runCommand(`summon pokemon:p${getScore("entityserp",s)}`);s.runCommand("tag @e[family=pokemon,tag=!tamed,tag=!evolving,c=1] add evolved");s.runCommand("tag @e[family=pokemon,tag=evolved,tag=!evolving,c=1] add tamed");s.getTags().forEach(tag=>{if(tag.includes("owner&")&&(!s.hasTag("evolved"))){s.runCommand(`tag @e[family=pokemon,c=1,tag=evolved] add "${tag}"`);}});s.runCommand(`${sc}ball ${getScore("ball",s)}`);s.runCommand(`${sc}subspc ${getScore("subspc",s)}`);s.runCommand(`${sc}condition ${getScore("condition",s)}`);s.runCommand(`${sc}amistadserp ${getScore("amistadserp",s)}`);s.runCommand(`${sc}exp ${getScore("exp",s)}`);s.runCommand(`${sc}naturaleza ${getScore("naturaleza",s)}`);s.runCommand(`${sc}ability ${getScore("ability",s)}`);s.runCommand(`${sc}item ${getScore("item",s)}`);s.runCommand(`${sc}gigamaxf ${getScore("gigamaxf",s)}`);s.runCommand(`${sc}dynamaxl ${getScore("dynamaxl",s)}`);s.runCommand(`${sc}attack1 ${getScore("attack1",s)}`);s.runCommand(`${sc}attack2 ${getScore("attack2",s)}`);s.runCommand(`${sc}attack3 ${getScore("attack3",s)}`);s.runCommand(`${sc}attack4 ${getScore("attack4",s)}`);if(s.nameTag){s.runCommand(`tag @e[family=pokemon,c=1,tag=evolved] add "nickname&${s.nameTag}"`);}s.runCommand(`event entity @e[family=pokemon,c=1,tag=evolved] serp:v${getScore("variant",s)}`);}
    else if(s.hasTag("defeated")&&(!s.hasTag("tamed")&&!s.hasTag("from_trainer"))){s.runCommand("particle serp:wild_back ~~~");}
    else if(s.hasTag("from_trainer")){s.runCommand("particle serp:back ~~~");}
    };break;
    case("serp:healing"):{let s1="0";let s2="0";let s3="0";let s4="0";let s5="0";let s6="0";s.getTags().forEach(tag=>{let p=tag.split("/");if(tag.startsWith("team1/")){s1=`team1/${p[1]}/${p[2]}/${p[3]}/${p[4]}/999/0/${p[7]}/${p[8]}/${p[9]}/${p[10]}/${p[11]}/${p[12]}/${p[13]}/${p[14]}/${p[15]}/${p[16]}/${p[17]}/${p[18]}`;s.removeTag(tag);}if(tag.startsWith("team2/")){s1=`team2/${p[1]}/${p[2]}/${p[3]}/${p[4]}/999/0/${p[7]}/${p[8]}/${p[9]}/${p[10]}/${p[11]}/${p[12]}/${p[13]}/${p[14]}/${p[15]}/${p[16]}/${p[17]}/${p[18]}`;s.removeTag(tag);}if(tag.startsWith("team3/")){s1=`team3/${p[1]}/${p[2]}/${p[3]}/${p[4]}/999/0/${p[7]}/${p[8]}/${p[9]}/${p[10]}/${p[11]}/${p[12]}/${p[13]}/${p[14]}/${p[15]}/${p[16]}/${p[17]}/${p[18]}`;s.removeTag(tag);}if(tag.startsWith("team4/")){s1=`team4/${p[1]}/${p[2]}/${p[3]}/${p[4]}/999/0/${p[7]}/${p[8]}/${p[9]}/${p[10]}/${p[11]}/${p[12]}/${p[13]}/${p[14]}/${p[15]}/${p[16]}/${p[17]}/${p[18]}`;s.removeTag(tag);}if(tag.startsWith("team5/")){s1=`team5/${p[1]}/${p[2]}/${p[3]}/${p[4]}/999/0/${p[7]}/${p[8]}/${p[9]}/${p[10]}/${p[11]}/${p[12]}/${p[13]}/${p[14]}/${p[15]}/${p[16]}/${p[17]}/${p[18]}`;s.removeTag(tag);}if(tag.startsWith("team6/")){s1=`team6/${p[1]}/${p[2]}/${p[3]}/${p[4]}/999/0/${p[7]}/${p[8]}/${p[9]}/${p[10]}/${p[11]}/${p[12]}/${p[13]}/${p[14]}/${p[15]}/${p[16]}/${p[17]}/${p[18]}`;s.removeTag(tag);}if(s1!=="0"){s.addTag(s1);}if(s2!=="0"){s.addTag(s2);}if(s3!=="0"){s.addTag(s3);}if(s4!=="0"){s.addTag(s4);}if(s5!=="0"){s.addTag(s5);}if(s6!=="0"){s.addTag(s6);}});};break;
    case("serp:on_attack"):{s.addTag("on_attack");setScore(s,"STGC2",8);};break;
    case("serp:end_attack"):{s.removeTag("on_attack")};break;
    case("serp:end_battle"):{let mer=0;s.runCommand(`loot give @p[scores={VICN=${getScore('VICN',s)}}] loot "entities/battle_win"`);for(const trainer of trainers){if(getScore("TrainerID",s)==trainer.Tid){mer=Math.round((Math.random()*150)+50)+trainer.cusmn;}}s.runCommand(`scoreboard players add @p[scores={VICN=${getScore('VICN',s)}}] money ${mer}`);s.runCommand(`tellraw @p[scores={VICN=${getScore("VICN",s)}}] {"rawtext":[{"selector":"@p[scores={VICN=${getScore('VICN',s)}}]"},{"translate":"combat.received"},{"text":" ${mer}"}]}`);if(getScore("TrainerID",s)==50){s.runCommand(`scoreboard players add @p[scores={VICN=${getScore('VICN',s)}}] chips 5`);};s.runCommand(`scoreboard players set @p[scores={VICN=${getScore('VICN',s)}}] VICN 0`);};break;
    case("serp:surrender"):{s.runCommand(`event entity @e[scores={VICT=${getScore('VICT',s)}}] serp:despawn`);s.runCommand(`scoreboard players remove @p[scores={VICN=${getScore('VICN',s)}}] money ${Math.floor(Math.random()*250)+100}`);s.runCommand(`scoreboard players set @p[scores={VICN=${getScore('VICN',s)}}] VICN 0`)};break;
    case("serp:defeated"):{s.runCommand("function battle/battle_defeated");s.runCommand(`event entity @e[family=serp_npc,rm=0.2,c=1,scores={VICT=${getScore("VICT",s)}}] serp:lose_battle`);};break;
    case("serp:mega"):{s.addTag("mega");};break;
    case("serp:totem"):{s.addTag("totem");};break;
    case("serp:mega2"):{s.addTag("mega");};break;
    case("serp:max"):{s.addTag("max");};break;
    case("serp:normalize"):{if(s.hasTag("mega")){s.removeTag("mega");}else if(s.hasTag("totem")){s.removeTag("totem");}else if(s.hasTag("max")){s.removeTag("max");}};break;
    case("serp:wild_attack"):{s.runCommand("function battle/wild_attack")};break;
    case("serp:reset"):{if(s.typeId==="serp:trade_machine"){Array.from(world.getPlayers()).forEach(player=>{if(getScore("mount",player)==getScore("mount",s)){player.runCommand(`titleraw @s actionbar {"rawtext":[{"translate":"serp.trade_finished"}]}`);if(player.hasTag("summary")){player.removeTag("summary")}}});s.traded1="0";s.traded2="0";setScore(s,"level",0);setScore(s,"mount",0);}if(s.typeId==="serp:slot_machine"){let rdd=setScoreR(1,100);let chipsc=0;if(rdd>=41&&rdd<=70){chipsc=setScoreR(1,15);}if(rdd>=71&&rdd<=90){s.runCommand(`loot give @p[scores={TrainerID=${getScore("TrainerID",s)}}] loot "entities/trade_resources"`);s.runCommand("particle serp:bet_loot ^^^1");}if(rdd>=91&&rdd<=100){chipsc=setScoreR(40,60);}if(chipsc>=1){s.runCommand(`tellraw @p[scores={TrainerID=${getScore("TrainerID",s)}}] {"rawtext":[{"text":" +${chipsc}"}]}`);s.runCommand("particle serp:bet_chips ^^^1");}s.runCommand(`scoreboard players add @p[scores={TrainerID=${getScore("TrainerID",s)}}] chips ${chipsc}`);}};break;
    case("serp:time_up"):{let multiplier=1;let capturable=Math.floor(Math.random()*255);let cc=`scoreboard players set @p[scores={TrainerID=${getScore("TrainerID",s)}}] CombatC `;
    if(getScore("ball",s)==1){multiplier=1;}
    if(getScore("ball",s)==2){multiplier=1.5;}
    if(getScore("ball",s)==3){multiplier=2;}
    if(getScore("ball",s)==4){multiplier=255;}
    if(getScore("ball",s)==5){if(s.hasTag("beast")){multiplier=3;}else{multiplier=0.1;}}
    if(getScore("ball",s)==6){if(s.hasTag("diving")){multiplier=3;}else{multiplier=1;}}
    if(getScore("ball",s)==7){if(s.hasTag("dream")){multiplier=3;}else{multiplier=1;}}
    if(getScore("ball",s)==8){if(s.hasTag("dusk")){multiplier=3;}else{multiplier=1;}}
    if(getScore("ball",s)==9){if(s.hasTag("fast")){multiplier=3;}else{multiplier=1;}}
    if(getScore("ball",s)==10){multiplier=1;setScore(s,"amistadserp",100,"add");}
    if(getScore("ball",s)==11){multiplier=1;setScore(s,"HPserpC",999);setScore(s,"condition",0);}
    if(getScore("ball",s)==12){if(s.hasTag("heavy")){multiplier=3;}else{multiplier=1;}}
    if(getScore("ball",s)==13){if(s.hasTag("diving")){multiplier=3;}else{multiplier=1;}}
    if(getScore("ball",s)==14){multiplier=1;setScore(s,"amistadserp",85,"add");}
    if(getScore("ball",s)==15){if(s.hasTag("moon")){multiplier=3;}else{multiplier=1;}}
    if(getScore("ball",s)==16){if(getScore("exp",s)>=50&&getScore("exp",s)<500){multiplier=3;}else if(getScore("exp",s)>=500&&getScore("exp",s)<1000){multiplier=2;}else if(getScore("exp",s)>=1000){multiplier=1;}}
    if(getScore("ball",s)==17){if(s.hasTag("net")){multiplier=3;}else{multiplier=1;}}
    if(getScore("ball",s)==18){if(s.hasTag("park")){multiplier=3;}else{multiplier=1;}}
    if(getScore("ball",s)==19){multiplier=2;}
    if(getScore("ball",s)==20){if(s.hasTag("safari")){multiplier=3;}else{multiplier=1;}}
    if(getScore("ball",s)==21){if(s.hasTag("timer")){multiplier=2;}else{multiplier=1;}}
    let capture=Math.round(getScore("CaptureRatio",s)*multiplier);
    if(capturable<capture){s.triggerEvent("serp:pre_take");s.runCommand(`${cc} 128`);}
    if(capturable>=capture){let fail=Math.floor(capturable-capture);let failed=Math.floor((255-capture)/3);
    if(fail>=(failed*2)&&capturable<256){s.triggerEvent("serp:pre_free1");s.runCommand(`${cc} 76`);}
    else if(fail>=(failed*1)&&fail<(failed*2)){s.triggerEvent("serp:pre_free2");s.runCommand(`${cc} 94`);}
    else if(fail>=1&&fail<(failed*1)){s.triggerEvent("serp:pre_free3");s.runCommand(`${cc} 124`);}}};break;
    case("serp:take"):{let sc=`scoreboard players set @p[scores={TrainerID=${getScore("TrainerID",s)}}]`;if(s.typeId==="serp:pokeball"){s.runCommand(`tellraw @p[scores={TrainerID=${getScore("TrainerID",s)}}] {"rawtext":[{"translate":"ball.catch"},{"translate":"entity.pokemon:p${getScore('entityserp',s)}.name"},{"text":"!"}]}`);}s.runCommand(`playsound serp.pokeball.capture @p[scores={TrainerID=${getScore("TrainerID",s)}}]`);s.runCommand(`playsound serp.pokeball.capture @p[scores={TrainerID=${getScore("TrainerID",s)}}]`);s.runCommand(`${sc} ball ${getScore("ball",s)}`);s.runCommand(`${sc} variant ${getScore("variant",s)}`);s.runCommand(`${sc} subspc ${getScore("subspc",s)}`);s.runCommand(`${sc} HPserpC ${getScore("HPserpC",s)}`);s.runCommand(`${sc} condition ${getScore("condition",s)}`);s.runCommand(`${sc} amistadserp ${getScore("amistadserp",s)}`);s.runCommand(`${sc} exp ${getScore("exp",s)}`);s.runCommand(`${sc} naturaleza ${getScore("naturaleza",s)}`);s.runCommand(`${sc} ability ${getScore("ability",s)}`);s.runCommand(`${sc} item ${getScore("item",s)}`);s.runCommand(`${sc} gigamaxf ${getScore("gigamaxf",s)}`);s.runCommand(`${sc} dynamaxl ${getScore("dynamaxl",s)}`);s.runCommand(`${sc} attack1 ${getScore("attack1",s)}`);s.runCommand(`${sc} attack2 ${getScore("attack2",s)}`);s.runCommand(`${sc} attack3 ${getScore("attack3",s)}`);s.runCommand(`${sc} attack4 ${getScore("attack4",s)}`);s.runCommand(`${sc} entityserp ${getScore("entityserp",s)}`);};break;
    case("serp:free"):{const sc="scoreboard players set @e[family=pokemon,c=1] ";s.runCommand(`tellraw @p[scores={TrainerID=${getScore("TrainerID",s)}}] {"rawtext":[{"translate":"entity.pokemon:p${getScore('entityserp',s)}.name"},{"translate":"ball.free"}]}`);s.runCommand(`summon pokemon:p${getScore("entityserp",s)} ~~~ ~~ serp:v${getScore("variant",s)}`);s.runCommand(`${sc} ball ${getScore("ball",s)}`);s.runCommand(`${sc} subspc ${getScore("subspc",s)}`);s.runCommand(`${sc} HPserpC ${getScore("HPserpC",s)}`);s.runCommand(`${sc} condition ${getScore("condition",s)}`);s.runCommand(`${sc} amistadserp ${getScore("amistadserp",s)}`);s.runCommand(`${sc} exp ${getScore("exp",s)}`);s.runCommand(`${sc} naturaleza ${getScore("naturaleza",s)}`);s.runCommand(`${sc} ability ${getScore("ability",s)}`);s.runCommand(`${sc} item ${getScore("item",s)}`);s.runCommand(`${sc} gigamaxf ${getScore("gigamaxf",s)}`);s.runCommand(`${sc} dynamaxl ${getScore("dynamaxl",s)}`);s.runCommand(`${sc} attack1 ${getScore("attack1",s)}`);s.runCommand(`${sc} attack2 ${getScore("attack2",s)}`);s.runCommand(`${sc} attack3 ${getScore("attack3",s)}`);s.runCommand(`${sc} attack4 ${getScore("attack4",s)}`);};break;
    }
    if(event.eventId.includes("serp:v")){s.getTags().forEach(tag=>{if(tag.startsWith("nickname&")){s.nameTag=tag.replace("nickname&","");s.removeTag(tag);}});if(getScore('HPserpC',s)){hp.setCurrentValue(getScore('HPserpC',s));}setScore(s,"variant",event.eventId.replace("serp:v","")*1);s.runCommand(`function pokemon/${s.typeId.replace("pokemon:p","")}`);setScore(s,"HPserpM",hp.defaultValue);s.runCommand("scoreboard players add @s STGC2 0");s.runCommand("scoreboard players add @s attackl 0");s.runCommand("scoreboard players add @s VIC 0");s.runCommand("scoreboard players add @s SerpAngry 0");s.runCommand("scoreboard players add @s CombatTimer 0");}
});
world.afterEvents.projectileHitEntity.subscribe((hit)=>{try{
let s=hit.source;let b=hit.projectile;let p=hit.getEntityHit().entity;let hp=p.getComponent('health');
if((p.typeId.startsWith("pokemon:")&&p.hasTag("spawned")&&b.typeId==="serp:ball_thrown")&&((p.hasTag("legendary")&&hp.currentValue<=Math.floor(hp.defaultValue/10))||(!p.hasTag("legendary")))&&!p.hasTag("on_capture")&&!p.hasTag("tamed")&&!b.hasTag("capturing")&&!p.hasTag("from_trainer")&&!p.hasTag("evolved"))
{let be=0;
if(getScore("condition",p)>0){be=10;}
let capture=Math.floor(((((3*hp.defaultValue)-(2*hp.currentValue))*getScore("CaptureRatio",p))/(3*hp.defaultValue))+be)
setScore(p,"TrainerID",getScore("TrainerID",s));b.addTag("capturing");p.addTag("on_capture");setScore(p,"CaptureRatio",capture);
if(b.hasTag("pokeball")){p.addTag("pokeball");}
if(b.hasTag("greatball")){p.addTag("greatball");}
if(b.hasTag("ultraball")){p.addTag("ultraball");}
if(b.hasTag("masterball")){p.addTag("masterball");}
if(b.hasTag("beastball")){p.addTag("beastball");}
if(b.hasTag("diveball")){p.addTag("diveball");}
if(b.hasTag("dreamball")){p.addTag("dreamball");}
if(b.hasTag("duskball")){p.addTag("duskball");}
if(b.hasTag("fastball")){p.addTag("fastball");}
if(b.hasTag("friendball")){p.addTag("friendball");}
if(b.hasTag("healball")){p.addTag("healball");}
if(b.hasTag("heavyball")){p.addTag("heavyball");}
if(b.hasTag("lureball")){p.addTag("lureball");}
if(b.hasTag("luxuryball")){p.addTag("luxuryball");}
if(b.hasTag("moonball")){p.addTag("moonball");}
if(b.hasTag("nestball")){p.addTag("nestball");}
if(b.hasTag("netball")){p.addTag("netball");}
if(b.hasTag("parkball")){p.addTag("parkball");}
if(b.hasTag("premierball")){p.addTag("premierball");}
if(b.hasTag("safariball")){p.addTag("safariball");}
if(b.hasTag("timerball")){p.addTag("timerball");}
p.runCommand(`tp @s ~~0.3~ facing @p[name="${s.nameTag}"] false`);p.runCommand(`tp @s ~~~ ~ 0`);p.runCommand(`execute as @s at @s run camera @p[name="${s.nameTag}"] set minecraft:free ease 0.2 in_circ pos ^^1^1.5 rot 35~180`);b.triggerEvent("serp:capturing");p.triggerEvent("serp:capture");}
}catch(error){}});
world.afterEvents.entityHitEntity.subscribe((hit)=>{
let victim=hit.hitEntity;let hitter=hit.damagingEntity;let hnt=hitter.nameTag;let ps=victim.getComponent('health');let item=hitter.getComponent("inventory").container.getItem(hitter.selectedSlot);let fp='particle serp:heart ~~~';let fs='serp.friendship';let hp='particle serp:heal_green ~~~';let hps='serp.heal.item';let eqs='mob.horse.leather';
if(victim.typeId==="serp:trainer"&&item.typeId==="minecraft:compass"&&getScore("VICN",hitter)==0&&(!victim.getComponent("minecraft:is_saddled"))){let exps=[];hitter.getTags().forEach(tag=>{if(tag.includes("team")){exps.push(tag.split("/")[8]*1);}});setScore(hitter,"VICN",getScore("VICN",victim));if(getScore("TrainerID",victim)>30&&getScore("TrainerID",victim)<=48){let exp=exps.reduce(function(a,b){return(a>b)?a:b;});setScore(victim,"exp",getScore("exp",victim)+exp);}else{let exp=exps.reduce((a,b)=>a+b,0);setScore(victim,"exp",getScore("exp",victim)+(exp/exps.length));}victim.triggerEvent("serp:pre_battle");}
if(victim.typeId==="serp:healing_machine"&&item.typeId==="minecraft:compass"&&(!victim.hasTag("using"))){victim.triggerEvent("serp:using");hitter.runCommand("function dialogues/hard_return");hitter.playSound("serp.heal.machine");}
if(victim.typeId==="serp:pc_box"&&item.typeId==="minecraft:compass"){hitter.box=0;hitter.playSound("mob.pc.boot_on");forms.stg(hitter);}
if(victim.typeId==="serp:trade_machine"&&item.typeId==="minecraft:compass"){if(getScore("mount",victim)==0){victim.runCommand("scoreboard players random @s mount 1 9999");}hitter.getTags().forEach(tag=>{if(tag.includes("use_slot")){hitter.select=tag.replace("use_slot","");}});
if(!hitter.hasTag("out_slot1")&&!hitter.hasTag("out_slot2")&&!hitter.hasTag("out_slot3")&&!hitter.hasTag("out_slot4")&&!hitter.hasTag("out_slot5")&&!hitter.hasTag("out_slot6")&&(hitter.select!=0&&getScore(`team${hitter.select}`,hitter)>0)){
if(getScore("level",victim)==0){hitter.addTag("trader1");setScore(victim,"level",1,"add");setScore(hitter,"mount",getScore("mount",victim));hitter.addTag("summary");hitter.getTags().forEach(tag=>{if(tag.includes(`team${hitter.select}`)){victim.traded1=tag.replace(tag.split("/")[0],"");hitter.runCommand(`tellraw @a[r=10] {"rawtext":[{"text":"<"},{"selector":"@s"},{"text":"> "},{"translate":"serp.will_trade"},{"translate":"entity.pokemon:p${tag.split("/")[2]}.name"}]}`);}});hitter.playSound("mob.pc.boot_on");victim.triggerEvent("serp:trader1");}
else if(getScore("level",victim)==1&&(!hitter.hasTag("trader1"))){hitter.addTag("trader2");setScore(victim,"level",1,"add");setScore(hitter,"mount",getScore("mount",victim));hitter.addTag("summary");hitter.getTags().forEach(tag=>{if(tag.includes(`team${hitter.select}`)){victim.traded2=tag.replace(tag.split("/")[0],"");hitter.runCommand(`tellraw @a[r=10] {"rawtext":[{"text":"<"},{"selector":"@s"},{"text":"> "},{"translate":"serp.will_trade"},{"translate":"entity.pokemon:p${tag.split("/")[2]}.name"}]}`);}});hitter.playSound("mob.pc.boot_on");victim.triggerEvent("serp:trader2");}
else if(getScore("level",victim)==2&&getScore("mount",hitter)==getScore("mount",victim)&&hitter.hasTag("trader1")){setScore(victim,"level",1,"add");hitter.runCommand(`tellraw @a[r=10] {"rawtext":[{"text":"<"},{"selector":"@s"},{"text":"> "},{"translate":"serp.trade_confirmed"}]}`);hitter.playSound(hps);let p1=victim.traded1.split("/");let p2=victim.traded2.split("/");const trades=[{id:"61",td:"186",eqp:"26",gen:"2"},{id:"64",td:"65",eqp:"0",gen:"1"},{id:"67",td:"68",eqp:"0",gen:"1"},{id:"75",td:"76",eqp:"0",gen:"1"},{id:"79",td:"199",eqp:"26",gen:"2"},{id:"93",td:"94",eqp:"0",gen:"1"},{id:"95",td:"208",eqp:"27",gen:"2"},{id:"117",td:"230",eqp:"0",gen:"2"},{id:"123",td:"212",eqp:"27",gen:"2"}];for(const trade of trades){if(victim.traded1!=="0"&&victim.traded1.split("/")[2]===trade.id&&victim.traded1.split("/")[10]===trade.eqp&&hitter.hasTag(`gen${trade.gen}`)){victim.traded1=`/${p1[1]}/${trade.td}/${p1[3]}/${p1[4]}/999/${p1[6]}/${p1[7]}/${p1[8]}/${p1[9]}/0/${p1[11]}/${p1[12]}/${p1[13]}/${p1[14]}/${p1[15]}/${p1[16]}/${p1[17]}/${p1[18]}`;}if(victim.traded2!=="0"&&victim.traded2.split("/")[2]===trade.id&&victim.traded2.split("/")[10]===trade.eqp&&hitter.hasTag(`gen${trade.gen}`)){victim.traded2=`/${p2[1]}/${trade.td}/${p2[3]}/${p2[4]}/999/${p2[6]}/${p2[7]}/${p2[8]}/${p2[9]}/0/${p2[11]}/${p2[12]}/${p2[13]}/${p2[14]}/${p1[15]}/${p1[16]}/${p1[17]}/${p1[18]}`;}}}
else if(getScore("level",victim)==3&&getScore("mount",hitter)==getScore("mount",victim)&&hitter.hasTag("trader2")){Array.from(world.getPlayers()).forEach(player=>{if(getScore("mount",player)==getScore("mount",victim)&&player.hasTag("trader1")){player.getTags().forEach(tag=>{if(tag.includes(`team${player.select}`)){let act=`team${player.select}${victim.traded2}`;if(tag!==act){player.removeTag(tag);}player.addTag(act);}});}if(getScore("mount",player)==getScore("mount",victim)&&player.hasTag("trader2")){player.getTags().forEach(tag=>{if(tag.includes(`team${player.select}`)){let act=`team${player.select}${victim.traded1}`;if(tag!==act){player.removeTag(tag);}player.addTag(act);}});}});hitter.playSound("mob.pc.boot_on");victim.triggerEvent("serp:reset");}
}
else{hitter.runCommand('tellraw @s {"rawtext":[{"translate":"serp.fix_trade"}]}');hitter.runCommand('titleraw @s actionbar{"rawtext":[{"text":"X"}]}');}
}
if(victim.typeId==="serp:store"||victim.typeId==="serp:rotomarket"){if(item.typeId==="minecraft:compass"){hitter.playSound("mob.pc.boot_on");forms.store(hitter);}else{
const articles=[{id:"serp:pokeball",cost:100},{id:"serp:greatball",cost:300},{id:"serp:ultraball",cost:400},{id:"serp:masterball",cost:3000},{id:"serp:beastball",cost:700},{id:"serp:diveball",cost:500},{id:"serp:dreamball",cost:400},{id:"serp:duskball",cost:500},{id:"serp:fastball",cost:600},{id:"serp:friendball",cost:400},{id:"serp:healball",cost:300},{id:"serp:heavyball",cost:500},{id:"serp:lureball",cost:300},{id:"serp:luxuryball",cost:500},{id:"serp:moonball",cost:450},{id:"serp:nestball",cost:500},{id:"serp:netball",cost:500},{id:"serp:parkball",cost:200},{id:"serp:premierball",cost:600},{id:"serp:safariball",cost:450},{id:"serp:timerball",cost:500},{id:"serp:down_part",cost:75},{id:"serp:potion",cost:100},{id:"serp:super_potion",cost:200},{id:"serp:hyper_potion",cost:400},{id:"serp:max_potion",cost:625},{id:"serp:full_heal",cost:200},{id:"serp:full_restore",cost:750},{id:"serp:revive",cost:375},{id:"serp:max_revive",cost:1000},{id:"serp:fresh_water",cost:100},{id:"serp:soda_pop",cost:150},{id:"serp:lemonade",cost:175},{id:"serp:moomoo_milk",cost:300},{id:"serp:poke_toy",cost:900},{id:"serp:fluffy_tail",cost:400},{id:"serp:rare_candy",cost:5000},{id:"serp:metal_coat",cost:750},{id:"serp:kings_rock",cost:750},{id:"serp:clefairy_plush",cost:900},{id:"serp:pichu_plush",cost:900},{id:"serp:mulch",cost:75},{id:"serp:repel",cost:200},{id:"serp:super_repel",cost:350},{id:"serp:max_repel",cost:450},{id:"serp:fire_stone",cost:750},{id:"serp:thunder_stone",cost:750},{id:"serp:moon_stone",cost:750},{id:"serp:water_stone",cost:750},{id:"serp:leaf_stone",cost:750},{id:"serp:sun_stone",cost:750},{id:"serp:mt_bug",cost:650},{id:"serp:mt_dark",cost:650},{id:"serp:mt_dragon",cost:650},{id:"serp:mt_electric",cost:650},{id:"serp:mt_fairy",cost:650},{id:"serp:mt_fighting",cost:650},{id:"serp:mt_fire",cost:650},{id:"serp:mt_flying",cost:650},{id:"serp:mt_ghost",cost:650},{id:"serp:mt_grass",cost:650},{id:"serp:mt_ground",cost:650},{id:"serp:mt_ice",cost:650},{id:"serp:mt_normal",cost:650},{id:"serp:mt_poison",cost:650},{id:"serp:mt_psychic",cost:650},{id:"serp:mt_rock",cost:650},{id:"serp:mt_steel",cost:650},{id:"serp:mt_water",cost:650}]
for(const article of articles){if(article.id==item.typeId){setScore(hitter,"money",getScore("money",hitter)+article.cost);hitter.runCommand(`tellraw @s {"rawtext":[{"translate":"store.sold"},{"text":"  ${article.cost}"}]}`);hitter.runCommand(`clear @s ${article.id} 0 1`);}}
}}
if(victim.typeId==="serp:mini_lab"){const materials=[{id:"serp:pokemon_egg",pk:[10,13,16,19,129,161,163,165,167,172,175,261,263,265,270,273,276],vr:"both",atk1:241,atk2:257},{id:"serp:fossil_helix",pk:[138],vr:"both",atk1:241,atk2:257},{id:"serp:fossil_dome",pk:[140],vr:"both",atk1:242,atk2:256},{id:"serp:ancient_amber",pk:[142],vr:"both",atk1:143,atk2:303},{id:"serp:dna",pk:[151],vr:"no_gender",atk1:291,atk2:311},{id:"serp:fossil_root",pk:[345],vr:"both",atk1:241,atk2:257},{id:"serp:fossil_claw",pk:[347],vr:"both",atk1:242,atk2:256},{id:"serp:fossil_skull",pk:[408],vr:"both",atk1:241,atk2:257},{id:"serp:fossil_armor",pk:[410],vr:"both",atk1:241,atk2:257},{id:"serp:fossil_shell",pk:[564],vr:"both",atk1:241,atk2:257},{id:"serp:fossil_plume",pk:[566],vr:"both",atk1:242,atk2:256},{id:"serp:fossil_jaw",pk:[696],vr:"both",atk1:241,atk2:257},{id:"serp:fossil_sail",pk:[698],vr:"both",atk1:241,atk2:257},{id:"serp:fossil_bird"},{id:"serp:fossil_fish"},{id:"serp:fossil_drake"},{id:"serp:fossil_dino"}];
for(const material of materials){if(item.typeId===material.id&&(!victim.hasTag("working"))){victim.addTag(material.id);victim.triggerEvent(material.id);victim.triggerEvent("serp:working");hitter.runCommand(`clear @s ${material.id} 0 1`);}else if(victim.hasTag("finished")&&victim.hasTag(material.id)){var r=setScoreR(1,202);var v=0;setScore(hitter,"ball",1);if(material.vr==="both"){if(r>=1&&r<=160){v=1}else if(r>=161&&r<=200){v=2}else if(r==201){v=4}else if(r==202){v=5};}else if(material.vr==="male"){if(r>=1&&r<=200){v=1}else if(r>=201&&r<=202){v=4}}else if(material.vr==="female"){if(r>=1&&r<=200){v=2}else if(r>=201&&r<=202){v=5}}else if(material.vr==="no_gender"){if(r>=1&&r<=200){v=0}else if(r>=201&&r<=202){v=3}};setScore(hitter,"variant",v);setScore(hitter,"subspc",0);setScore(hitter,"HPserpC",999);setScore(hitter,"condition",0);setScore(hitter,"amistadserp",5);setScore(hitter,"exp",250);setScore(hitter,"naturaleza",setScoreR(1,25));setScore(hitter,"ability",0);setScore(hitter,"item",0);setScore(hitter,"gigamaxf",0);setScore(hitter,"dynamaxl",0);setScore(hitter,"attack1",material.atk1);setScore(hitter,"attack2",material.atk2);setScore(hitter,"attack3",0);setScore(hitter,"attack4",0);setScore(hitter,"entityserp",getRandom(material.pk));hitter.runCommand("give @s bone_meal");victim.triggerEvent("serp:reset");victim.removeTag(material.id);}}}
if(victim.typeId==="serp:slot_machine"&&item.typeId==="minecraft:compass"&&(!victim.getComponent("minecraft:is_saddled"))){if(getScore("chips",hitter)<10){hitter.runCommand(`tellraw @s {"rawtext":[{"text":" X"}]}`);}else{victim.triggerEvent("serp:trading");setScore(hitter,"chips",Math.floor(getScore("chips",hitter)-10));setScore(victim,"TrainerID",getScore("TrainerID",hitter));}}
if(victim.typeId==="serp:hoopa_ring"&&(!victim.hasTag("used")&&(hitter.hasTag("gen1")||hitter.hasTag("gen2")||hitter.hasTag("gen3")))){const offers=[{item:"serp:articuno_offering",poke:144},{item:"serp:zapdos_offering",poke:145},{item:"serp:moltres_offering",poke:146},{item:"serp:jirachi_offering",poke:385}];for(const offer of offers){victim.addTag("used");victim.triggerEvent("serp:timer");if(offer.item==item.typeId){victim.addTag("legendary");victim.runCommand(`scoreboard players set @s entityserp ${offer.poke}`);hitter.runCommand(`clear @s ${offer.item} 0 1`);}}}
if(victim.typeId.startsWith("pokemon:")&&victim.hasComponent("is_tamed")&&(victim.hasTag(`owner&${hnt}&1`)||victim.hasTag(`owner&${hnt}&2`)||victim.hasTag(`owner&${hnt}&3`)||victim.hasTag(`owner&${hnt}&4`)||victim.hasTag(`owner&${hnt}&5`)||victim.hasTag(`owner&${hnt}&6`))&&victim.hasTag("spawned")&&getScore("CombatTimer",victim)==0&&(!hitter.hasTag("evolve")&&!victim.hasTag("evolving")))
    {let nick=`entity.pokemon:p${getScore("entityserp",victim)}.name`;if(victim.nameTag){nick=victim.nameTag}
    if(victim.hasTag("defeated")){switch(item.typeId){
    case("serp:revive"):{ps.setCurrentValue(Math.round(ps.defaultValue/2));victim.runCommand(`${hp}`);victim.triggerEvent("serp:revive");victim.removeTag("defeated");hitter.runCommand("clear @s serp:revive 0 1");hitter.playSound(`${hps}`);};break;
    case("serp:max_revive"):{ps.setCurrentValue(ps.defaultValue);victim.runCommand(`${hp}`);victim.triggerEvent("serp:revive");victim.removeTag("defeated");hitter.runCommand("clear @s serp:max_revive 0 1");hitter.playSound(`${hps}`);};break;
    }}
    if(!victim.hasTag("defeated")&&!hitter.isSneaking)
    {
    if(!victim.hasTag("battle")&&!victim.hasTag("learn_cancelled")&&(getScore('attackl',victim)>0&&((getScore('attack1',victim)<getScore('attackl',victim)||getScore('attack1',victim)>getScore('attackl',victim))&&(getScore('attack2',victim)<getScore('attackl',victim)||getScore('attack2',victim)>getScore('attackl',victim))&&(getScore('attack3',victim)<getScore('attackl',victim)||getScore('attack3',victim)>getScore('attackl',victim))&&(getScore('attack4',victim)<getScore('attackl',victim)||getScore('attack4',victim)>getScore('attackl',victim)))))
    {let icon;
    hitter.runCommand("function spawn/clear_menu");
    let form=new ActionFormData().title(`attack.${getScore('attackl',victim)}`).body("serp.mt_body")
    for(let u=1;u<5;u++){for(const attack of attacks){if(getScore(`attack${u}`,victim)==attack.Aid){form.button(`attack.${attack.Aid}`,`textures/type/${attack.icon}`)}}}
    form.show(hitter).then(r=>{
	if(r.canceled)return victim.addTag("learn_cancelled");
	let response=r.selection;
  if(!r.canceled){setScore(victim,`attack${response+1}`,getScore('attackl',victim));hitter.playSound("serp.learn_move");};
	});}
    switch(item.typeId){
    case("minecraft:compass"):{
    if(!victim.hasTag("battle")&&((getScore('attackl',victim)>0&&victim.hasTag("learn_cancelled"))||getScore('attackl',victim)==0||((getScore('attack1',victim)==getScore('attackl',victim))||(getScore('attack2',victim)==getScore('attackl',victim))||(getScore('attack3',victim)==getScore('attackl',victim))||(getScore('attack4',victim)==getScore('attackl',victim)))))
{hitter.runCommand("function spawn/clear_menu");let form=new ActionFormData();form.title("serp.pokemenu");form.body(" ");
form.button("serp.pet","textures/ui/pokemon/pet")
form.button(`mount.${getScore('mount',victim)}`,`textures/ui/pokemon/mount_${getScore('mount',victim)}`)
form.button("serp.remove_item","textures/ui/pokemon/remove_item")
form.button("serp.battle_b","textures/ui/status/0")
form.button("serp.nickname","textures/ui/pokemon/nickname")
form.button("serp.close_menu","textures/stg/decline")
{if((victim.hasTag("evolv")||victim.hasTag("evohappy"))&&victim.hasTag("can_evolve")){form.button("serp.evolve","textures/ui/pokemon/evolve")}}
    form.show(hitter).then(result=>{
	if(result.canceled)return hitter.runCommand();
	switch (result.selection){
case 0:victim.runCommand("function spawn/happiness");victim.runCommand(`${fp}`);break;
case 1:{if(getScore('mount',victim)==1){victim.runCommand(`ride @s start_riding @p[name="${hnt}"]`);}else if(getScore('mount',victim)==2){hitter.removeTag("summary")}else if(getScore('mount',victim)==3){victim.runCommand(`execute as @s if entity @p[name="${hnt}",hasitem={item=serp:poke_ride}] run event entity @s serp:saddle`);}}break;
case 2:victim.runCommand("function spawn/remove_item");break;
case 3:victim.addTag("battle");break;
case 4:{let nick="0";let actualNick=`entity.pokemon:p${getScore("entityserp",victim)}.name`;if(victim.nameTag){actualNick=victim.nameTag};let form=new ModalFormData();form.title("serp.nickname");form.textField(actualNick,"serp.new_nickname");
form.show(hitter).then(result=>{if(!result.canceled){nick=`${result.formValues}`;if(nick!==" "&&nick!==""&&nick!=="/"){if(nick.length>15){nick=nick.substring(0,15);};victim.addTag(`nickname&${nick}`);}else{victim.addTag(`nickname&`);}victim.triggerEvent(`serp:v${getScore("variant",victim)}`);}})};break;
case 5:hitter.runCommand("testfor @s");break;
case 6:{victim.triggerEvent("serp:evolve");hitter.triggerEvent("serp:on_evolve");hitter.runCommand("clear @s serp:rare_candy 0 1");hitter.playSound("serp.evolve");};break;
}});}
    else if((!hitter.isSneaking)&&victim.hasTag("battle"))
    {let icon;
    hitter.runCommand("function spawn/clear_menu");
    let form=new ActionFormData().title("serp.battle").body(" ")
for(let u=1;u<5;u++){for(const attack of attacks){if(getScore(`attack${u}`,victim)==attack.Aid){form.button(`attack.${attack.Aid}`,`textures/type/${attack.icon}`)}}}
form.button(`mechanic.${getScore('mechanic',hitter)}`,`textures/ui/battle/mechanic_${getScore('mechanic',hitter)}`)
form.button("serp.close_menu","textures/stg/decline")
    form.show(hitter).then(r=>{
	if(r.canceled)return;
	let response=r.selection;
	switch(response){
case 0:victim.addTag("use_attack1");victim.runCommand("function battle/attack");break;
case 1:victim.addTag("use_attack2");victim.runCommand("function battle/attack");break;
case 2:victim.addTag("use_attack3");victim.runCommand("function battle/attack");break;
case 3:victim.addTag("use_attack4");victim.runCommand("function battle/attack");break;
case 4:victim.addTag(`mechanic${getScore('mechanic',hitter)}`);victim.runCommand("function battle/serpbattle/mechanic");break;
case 5:hitter.runCommand();break;
    }
  });
}

    };break;
    case("serp:full_heal"):{if(getScore('condition',victim)>0){setScore(victim,"condition",0);victim.runCommand(`${hp}`);hitter.runCommand("clear @s serp:full_heal 0 1");hitter.playSound(`${hps}`);}};break;
    case("serp:full_restore"):{if(getScore('condition',victim)>0||ps.currentValue<ps.defaultValue){setScore(victim,"condition",0);ps.setCurrentValue(999);victim.runCommand(`${hp}`);hitter.runCommand("clear @s serp:full_restore 0 1");hitter.playSound(`${hps}`);}};break;
    }
    if((hitter.hasTag("gen1")&&victim.hasTag("toGen1"))||(hitter.hasTag("gen2")&&victim.hasTag("toGen2"))||(hitter.hasTag("gen3")&&victim.hasTag("toGen3")))
    {
    switch(item.typeId){
    case("serp:rare_candy"):{if(getScore('exp',victim)<5000){setScore(victim,"exp",50,"add");setScore(victim,"amistadserp",2,"add");victim.runCommand("particle serp:exp ~~~");hitter.runCommand("clear @s serp:rare_candy 0 1");hitter.playSound("serp.levelup");}};break;
    case("serp:linking_cord"):{if(victim.hasTag("evotrade")){victim.addTag("evolvingwithtrade");victim.triggerEvent("serp:evolve");hitter.triggerEvent("serp:on_evolve");hitter.runCommand("clear @s serp:linking_cord 0 1");hitter.playSound("serp.evolve");}};break;
    case("serp:fire_stone"):{if(victim.hasTag("evofirestone")){victim.addTag("evolvingwithfirestone");victim.triggerEvent("serp:evolve");hitter.triggerEvent("serp:on_evolve");hitter.runCommand("clear @s serp:fire_stone 0 1");hitter.playSound("serp.evolve");}};break;
    case("serp:thunder_stone"):{if(victim.hasTag("evothunderstone")){victim.addTag("evolvingwiththunderstone");victim.triggerEvent("serp:evolve");hitter.triggerEvent("serp:on_evolve");hitter.runCommand("clear @s serp:thunder_stone 0 1");hitter.playSound("serp.evolve");}};break;
    case("serp:water_stone"):{if(victim.hasTag("evowaterstone")){victim.addTag("evolvingwithwaterstone");victim.triggerEvent("serp:evolve");hitter.triggerEvent("serp:on_evolve");hitter.runCommand("clear @s serp:water_stone 0 1");hitter.playSound("serp.evolve");}};break;
    case("serp:leaf_stone"):{if(victim.hasTag("evoleafstone")){victim.addTag("evolvingwithleafstone");victim.triggerEvent("serp:evolve");hitter.triggerEvent("serp:on_evolve");hitter.runCommand("clear @s serp:leaf_stone 0 1");hitter.playSound("serp.evolve");}};break;
    case("serp:moon_stone"):{if(victim.hasTag("evomoonstone")){victim.addTag("evolvingwithmoonstone");victim.triggerEvent("serp:evolve");hitter.triggerEvent("serp:on_evolve");hitter.runCommand("clear @s serp:moon_stone 0 1");hitter.playSound("serp.evolve");}};break;
    case("serp:sun_stone"):{if(victim.hasTag("evosunstone")){victim.addTag("evolvingwithsunstone");victim.triggerEvent("serp:evolve");hitter.triggerEvent("serp:on_evolve");hitter.runCommand("clear @s serp:sun_stone 0 1");hitter.playSound("serp.evolve");}};break;
      }
    }
    if(((getScore('attack1',victim)<item.getLore()||getScore('attack1',victim)>item.getLore())&&(getScore('attack2',victim)<item.getLore()||getScore('attack2',victim)>item.getLore())&&(getScore('attack3',victim)<item.getLore()||getScore('attack3',victim)>item.getLore())&&(getScore('attack4',victim)<item.getLore()||getScore('attack4',victim)>item.getLore()))&&item.typeId.startsWith("serp:mt_")&&victim.hasTag(`MT${item.getLore()}`))
    {hitter.runCommand("function spawn/clear_menu");let cm='function spawn/clear_mt';let icon;
  let form=new ActionFormData().title(`attack.${item.getLore()}`).body("serp.mt_body")
  for(let u=1;u<5;u++){for(const attack of attacks){if(getScore(`attack${u}`,victim)==attack.Aid){form.button(`attack.${attack.Aid}`,`textures/type/${attack.icon}`)}}}
  form.show(hitter).then(r=>{let response=r.selection;
	if(r.canceled)return;else{setScore(victim,`attack${response+1}`,(item.getLore()*1));hitter.playSound("serp.learn_move");hitter.runCommand(`clear @s ${item.typeId} 0 1`);};
      });
    }
    if((getScore('attack1',victim)==item.getLore()||getScore('attack2',victim)==item.getLore()||getScore('attack3',victim)==item.getLore()||getScore('attack4',victim)==item.getLore()||(!victim.hasTag(`MT${item.getLore()}`)))&&item.typeId.startsWith("serp:mt_")){hitter.runCommand(`tellraw @s{"rawtext":[{"translate":"${nick}"},{"translate":"serp.cant_learn"},{"translate":"attack.${item.getLore()}"}]}`);}
    if(ps.currentValue<ps.defaultValue&&item.typeId.startsWith("serp:")&&(item.typeId.includes("potion")||item.typeId.includes("fresh_water")||item.typeId.includes("soda_pop")||item.typeId.includes("lemonade")||item.typeId.includes("moomoo_milk"))){ps.setCurrentValue(ps.currentValue+item.getComponent("durability").maxDurability);victim.runCommand(`${hp}`);hitter.runCommand(`clear @s ${item.typeId} 0 1`);hitter.playSound(`${hps}`);}
    if(getScore('item',victim)<1&&item.typeId.startsWith("serp:")&&(item.typeId.includes("berry")||item.typeId.includes("ite")||item.typeId==="serp:kings_rock"||item.typeId==="serp:metal_coat")){setScore(victim,"item",item.getComponent("durability").maxDurability);hitter.runCommand(`clear @s ${item.typeId} 0 1`);hitter.playSound(`${eqs}`);}
    if(getScore("amistadserp",victim)<255&&item.typeId.startsWith("serp:")&&(item.typeId.includes("plush")||item.typeId.includes("toy"))){victim.runCommand(`${fp}`);setScore(victim,"amistadserp",7,"add");hitter.runCommand(`clear @s ${item.typeId} 0 1`);hitter.playSound(`${fs}`);}
    if(item.typeId.startsWith("serp:pokepuff")){ps.setCurrentValue(ps.currentValue+3);victim.runCommand(`${fp}`);setScore(victim,"amistadserp",1,"add");hitter.runCommand(`clear @s ${item.typeId} 0 1`);hitter.playSound(`${hps}`);}
    if(getScore('amistadserp',victim)==255&&item.typeId.startsWith("serp:")&&item.typeId.includes("ball")){setScore(victim,"ball",item.getComponent("durability").maxDurability);setScore(victim,"amistadserp",150);hitter.runCommand(`clear @s ${item.typeId} 0 1`);hitter.playSound(`${eqs}`);}
    }
    else if(!victim.hasTag("defeated")&&(hitter.isSneaking))
    {
    if(item.typeId.includes("compass")){hitter.runCommand("titleraw @s times 0 0 0");hitter.runCommand(`titleraw @s subtitle {"rawtext":[{"translate":"${nick}"},{"translate":"condition.${getScore('condition',victim)}"},{"text":"\n"},{"translate":"serp.type"},{"translate":"type.${getScore('type1',victim)}"},{"text":", "},{"translate":"type.${getScore('type2',victim)}"},{"text":"\n"},{"translate":"serp.hp"},{"text":"${ps.currentValue}"},{"text":"/${ps.defaultValue}, "},{"translate":"serp.level"},{"text":"`+Math.floor(getScore('exp',victim)/50)+`"},{"text":"\n"},{"translate":"serp.happiness"},{"text":"${getScore('amistadserp',victim)}"},{"text":"/255"},{"text":"\n"},{"translate":"serp.item"},{"translate":"equippable.${getScore('item',victim)}"},{"text":"\n"},{"translate":"serp.nature"},{"translate":"nature.${getScore('naturaleza',victim)}"},{"text":"\n"},{"translate":"serp.attacks"},{"text":"\n"},{"translate":"attack.${getScore('attack1',victim)}"},{"text":"\n"},{"translate":"attack.${getScore('attack2',victim)}"},{"text":"\n"},{"translate":"attack.${getScore('attack3',victim)}"},{"text":"\n"},{"translate":"attack.${getScore('attack4',victim)}"}]}`);hitter.runCommand('titleraw @s title {"rawtext":[{"text":"s'+getScore("entityserp",victim)+'v'+getScore("variant",victim)+'"}]}');hitter.runCommand(`titleraw @s actionbar{"rawtext":[{"text":" "}]}`);hitter.runCommand("titleraw @s reset");hitter.addTag("summary");}
    }
  if(victim.hasTag("toGen1")){victim.removeTag("toGen1")}if(victim.hasTag("toGen2")){victim.removeTag("toGen2")}if(victim.hasTag("toGen3")){victim.removeTag("toGen3")}

}
});
world.afterEvents.entityHurt.subscribe((data)=>{let p=data.hurtEntity;let d=data.damage;let hc='function spawn/berry_heal';
  if((p.typeId.startsWith("pokemon:"))&&getScore('item',p)==9&&d>0){p.runCommand(`${hc}`);}
  if((p.typeId.startsWith("pokemon:"))&&getScore('item',p)==14&&d>10){p.runCommand(`${hc}`);}
  if((p.typeId.startsWith("pokemon:"))&&getScore('item',p)==7&&d>20){p.runCommand(`${hc}`);}
});
class gui{
    main(player){
    const form=new ActionFormData();form.title("serp.pokedex");form.body("feed.whatup")
    form.button("serp.pokemon","pokeitems/items/poke/poke_ball")
    form.button("serp.pokedex","pokeitems/items/poke/pokedex_closed")
    form.button(player.nameTag,"textures/ui/trainer_card")
    player.getTags().forEach(tag=>{if(tag.includes("max_vial")){form.button("serp.pokevial","textures/ui/pokevial")}});
    form.show(player).then(result=>{
    let response=result.selection
    if(result.canceled){player.removeTag("summary");player.removeTag("summary");}
    switch(response){
    case 0:{
    if(!player.hasTag("use_slot1")&&!player.hasTag("use_slot2")&&!player.hasTag("use_slot3")&&!player.hasTag("use_slot4")&&!player.hasTag("use_slot5")&&!player.hasTag("use_slot6")){player.runCommand('titleraw @s actionbar{"rawtext":[{"translate":"serp.no_slot_selected"}]}');player.removeTag("summary");}
    player.getTags().forEach(tag=>{
    if(tag.includes("use_slot")){let slot=tag.replace('use_slot','');
    if(player.hasTag("use_slot"+slot)&&getScore(('team'+slot),player)>0){this.slot_menu(player)}
    else if((player.hasTag("use_slot"+slot)&&getScore('team'+slot,player)==0)){player.runCommand('titleraw @s actionbar{"rawtext":[{"translate":"serp.empty_slot"}]}');player.removeTag("summary");player.removeTag(tag);}}});};break;
    case 1:this.pokedex(player);break;
    case 2:this.trainer_card(player);break;
    case 3:{if(getScore("pokevial",player)<=0){player.runCommand("camerashake add @s 0.5 0.2 positional");player.runCommand('tellraw @s {"rawtext":[{"translate":"serp.reload_pokevial"}]}');}else if(getScore("pokevial",player)>0){player.addTag("pokevial");player.runCommand("scoreboard players remove @s pokevial 1");player.runCommand("particle serp:heal_green ~~~");player.playSound("serp.heal.machine");player.runCommand("function dialogues/hard_return");}player.removeTag("summary");};break;
        }
      });
    }
    trainer_card(player){let s="0";let v="0";let nick="0";
    const form=new ActionFormData();form.title("serp.card");form.body(`${player.nameTag}\n\n\n\n\n\n\n\n\n\n ${getScore("money",player)}\n ${getScore("chips",player)}`)
    form.button(`ID No. ${getScore("TrainerID",player)}`,"pokeitems/items/icons/0");form.button(" ","pokeitems/items/icons/0");
    for(var u=1;u<=6;u++){player.getTags().forEach(tag=>{if(tag.startsWith(`team${u}/`)&&getScore(`team${u}`,player)>0){let p=tag.split("/");s=p[2];if(p[3]>=0&&p[3]<3){v=s}else if(p[3]>=3&&p[3]<6){v=s+"s"}if(p[18]==="0"){nick=`entity.pokemon:p${p[2]}.name`;}else{nick=p[18].replace("nickname&","");}}});if(getScore(`team${u}`,player)==0){s="0";v="0";nick="entity.pokemon:p0.name";}form.button(nick,`pokeitems/items/icons/${v}`)}
    form.show(player).then(result=>{
    if(result.canceled||!result.canceled){player.removeTag("summary");}
      });
    }
    slot_menu(player){
    const form=new ActionFormData();form.title("serp.team");form.body("serp.pokemonbody")
    form.button("serp.sb","textures/ui/pokemon/sb")
    form.button("serp.swipe","textures/ui/pokemon/swipe")
    form.button("serp.to_stg","textures/ui/pokemon/tostg")
    form.show(player).then(result=>{
    let response=result.selection
    if(result.canceled){this.main(player);}
    switch(response){
    case 0:{let slot="0";let nick="0";
    player.getTags().forEach(tag=>{if(tag.startsWith("use_slot")){slot=tag.replace('use_slot','');}});
    player.getTags().forEach(tag=>{if(tag.startsWith(`team${slot}/`)){if(tag.split("/")[18]==="0"){nick='entity.pokemon:p'+getScore(`team${slot}`,player)+'.name';}else{nick=tag.split("/")[18].replace("nickname&","");}}});
    if(!player.hasTag(`out_slot${slot}`)){player.addTag(`SMN${slot}`);player.triggerEvent("serp:spawn");}else{player.runCommand(`titleraw @s actionbar{"rawtext":[{"translate":"serp.return"},{"translate":"${nick}"},{"text":"!"}]}`);player.addTag(`return${slot}`);player.removeTag(`out_slot${slot}`);player.removeTag("summary");player.removeTag(`use_slot${slot}`);}
    };break;
    case 1:{
    if(player.hasTag("out_slot1")||player.hasTag("out_slot2")||player.hasTag("out_slot3")||player.hasTag("out_slot4")||player.hasTag("out_slot5")||player.hasTag("out_slot6")){player.runCommand('titleraw @s actionbar{"rawtext":[{"translate":"serp.save_pokemon"}]}');}
    else if(!player.hasTag("out_slot1")&&!player.hasTag("out_slot2")&&!player.hasTag("out_slot3")&&!player.hasTag("out_slot4")&&!player.hasTag("out_slot5")&&!player.hasTag("out_slot6"))
    {let s="0";let v="0";let nick="0";
    const form=new ActionFormData()
    form.title("serp.swipe");form.body("serp.swipebody")
    for(var u=1;u<=6;u++){player.getTags().forEach(tag=>{if(tag.startsWith(`team${u}/`)&&getScore(`team${u}`,player)>0){let p=tag.split("/");s=p[2];if(p[3]>=0&&p[3]<3){v=s}else if(p[3]>=3&&p[3]<6){v=s+"s"}if(p[18]==="0"){nick=`entity.pokemon:p${p[2]}.name`;}else{nick=p[18].replace("nickname&","");}}});if(getScore(`team${u}`,player)==0){s="0";v="0";nick="entity.pokemon:p0.name";}form.button(nick,`pokeitems/items/icons/${v}`)}
    form.show(player).then(result=>{
    const response=result.selection+1
    if(result.canceled){this.slot_menu(player);}
    if(!result.canceled){var slot="0";var from="0";var to="0";
    player.getTags().forEach(tag=>{if(tag.includes("use_slot")){slot=tag.replace('use_slot','');}});
    player.getTags().forEach(tag=>{if(tag.includes(`team${slot}`)){from=tag;}if(tag.includes(`team${response}`)&&getScore(`team${response}`,player)>0){to=tag;}});
    if(getScore(`team${response}`,player)==0){to=`team${response}/0/0`}
    player.removeTag(from);player.removeTag(to);let newfrom=from.replace((from.split("/")[0].replace("team","")),response);let newto=to.replace((to.split("/")[0].replace("team","")),slot);
    player.addTag(newfrom);player.addTag(newto);player.runCommand(`scoreboard players operation @s team${slot} >< @s team${response}`);player.runCommand('titleraw @s actionbar{"rawtext":[{"translate":"serp.swipped"}]}');player.removeTag(`use_slot${slot}`);player.removeTag("summary");}
    });
    }};break;
    case 2:{var slot="0";player.runCommand("function spawn/tostg");
    if(!player.hasTag("send_locked")){player.addTag("to_stg");
    player.getTags().forEach(tag=>{if(tag.includes("use_slot")){slot=tag.replace('use_slot','');}});
    if(player.hasTag(`out_slot${slot}`)){player.addTag(`return${slot}`);}
    player.getTags().forEach(tag=>{if(tag.includes(`team${slot}`)){let part=tag.split("/");setScore(player,"ball",part[1]*1);setScore(player,"entityserp",part[2]*1);setScore(player,"variant",part[3]*1);setScore(player,"subspc",part[4]*1);setScore(player,"HPserpC",part[5]*1);setScore(player,"condition",part[6]*1);setScore(player,"amistadserp",part[7]*1);setScore(player,"exp",part[8]*1);setScore(player,"naturaleza",part[9]*1);setScore(player,"ability",part[10]*1);setScore(player,"item",part[11]*1);setScore(player,"gigamaxf",part[12]*1);setScore(player,"dynamaxl",part[13]*1);setScore(player,"attack1",part[14]*1);setScore(player,"attack2",part[15]*1);setScore(player,"attack3",part[16]*1);setScore(player,"attack4",part[17]*1);if(part[18]!=="0"){player.addTag(part[18]);};setScore(player,`team${slot}`,0);player.removeTag(tag);}});}
    else{player.runCommand('tellraw @s {"rawtext":[{"translate":"serp.last_pokemon"}]}');player.removeTag("send_locked");}
    player.removeTag("summary");player.runCommand("title @s actionbar X");player.removeTag(`use_slot${slot}`);};break;
        }
      });
    }
    pokedex(player){
    const form=new ActionFormData();form.title("serp.pokedex");form.body(" ")
    form.button("Gen 1","textures/pokedex/dex.1");form.button("Gen 2","textures/pokedex/dex.152");form.button("Gen 3","textures/pokedex/dex.252")
    form.show(player).then(result=>{let response=result.selection;
    if(result.canceled){this.main(player);}
    switch(response){
    case 0:{if(player.hasTag("gen1")){const form=new ActionFormData();form.title("serp.pokedex");form.body(" ")
    for(var u=1;u<152;u++){form.button(`entity.pokemon:p${u}.name`,`textures/pokedex/dex.${u}`)}
    form.show(player).then(result=>{let response=result.selection;if(result.canceled){this.pokedex(player);}else{player.runCommand("dialogue open @e[type=serp:dialogue,c=1] @s p"+(response+1));}});}else{this.pokedex(player)}};break;
    case 1:{if(player.hasTag("gen2")){const form=new ActionFormData();form.title("serp.pokedex");form.body(" ")
    for(var u=1;u<101;u++){form.button(`entity.pokemon:p${u+151}.name`,`textures/pokedex/dex.${u+151}`)}
    form.show(player).then(result=>{let response=result.selection;if(result.canceled){this.pokedex(player);}else{player.runCommand("dialogue open @e[type=serp:dialogue,c=1] @s p"+(response+152));}});}else{this.pokedex(player)}};break;
    case 2:{if(player.hasTag("gen3")){const form=new ActionFormData();form.title("serp.pokedex");form.body(" ")
    for(var u=1;u<135;u++){form.button(`entity.pokemon:p${u+251}.name`,`textures/pokedex/dex.${u+251}`)}
    form.show(player).then(result=>{let response=result.selection;if(result.canceled){this.pokedex(player);}else{player.runCommand("dialogue open @e[type=serp:dialogue,c=1] @s p"+(response+252));}});}else{this.pokedex(player)}};break;
        }
      });
    }
    stg(player){
    const form=new ActionFormData();form.title("main.stg");form.body(` ${Math.floor((player.box/15)+1)}`)
    for(var u=1;u<=15;u++){let s=getScore(`stg${u+player.box}`,player);let v="0";let nick="0";player.getTags().forEach(tag=>{if(getScore(`stg${u+player.box}`,player)>0&&tag.startsWith(`stg${u+player.box}/`)){let p=tag.split("/");s=p[2];if(p[3]>=0&&p[3]<3){v=s}else if(p[3]>=3&&p[3]<6){v=s+"s"}if(p[18]==="0"){nick=`entity.pokemon:p${p[2]}.name`;}else{nick=p[18].replace("nickname&","");}}});if(getScore(`stg${u+player.box}`,player)==0){s="0";v="0";nick="entity.pokemon:p0.name";}form.button(nick,`pokeitems/items/icons/${v}`)}
    form.button("serp.change_box","textures/stg/changebox")
    form.show(player).then(result=>{
    var selected=result.selection+1;
    if(result.canceled){player.playSound("serp.market.store");player.removeTag("summary");}
    else if(selected!==16){
    if(getScore(`stg${selected+player.box}`,player)>0){const form=new ActionFormData()
    player.getTags().forEach(tag=>{let part=tag.split("/");if(tag.startsWith("stg"+(selected+player.box)+"/")){form.title(`stg${part[2]}v${part[3]}`);}});
    form.body("serp.stg_pokemon");
    form.button("serp.to_team","textures/ui/status/0");form.button("serp.release","textures/stg/release")
    form.show(player).then(result=>{
    let response=result.selection
    if(result.canceled){this.stg(player);}
    switch(response){
    case 0:{
    if(getScore("team1",player)>0&&getScore("team2",player)>0&&getScore("team3",player)>0&&getScore("team4",player)>0&&getScore("team5",player)>0&&getScore("team6",player)>0){player.runCommand('tellraw @s {"rawtext":[{"translate":"serp.full_team"}]}');}
    else if(getScore("team1",player)==0||getScore("team2",player)==0||getScore("team3",player)==0||getScore("team4",player)==0||getScore("team5",player)==0||getScore("team6",player)==0){
    player.getTags().forEach(tag=>{let part=tag.split("/");
    if(tag.startsWith("stg"+(selected+player.box)+"/")){setScore(player,"ball",part[1]*1);setScore(player,"entityserp",part[2]*1);setScore(player,"variant",part[3]*1);setScore(player,"subspc",part[4]*1);setScore(player,"HPserpC",part[5]*1);setScore(player,"condition",part[6]*1);setScore(player,"amistadserp",part[7]*1);setScore(player,"exp",part[8]*1);setScore(player,"naturaleza",part[9]*1);setScore(player,"ability",part[10]*1);setScore(player,"item",part[11]*1);setScore(player,"gigamaxf",part[12]*1);setScore(player,"dynamaxl",part[13]*1);setScore(player,"attack1",part[14]*1);setScore(player,"attack2",part[15]*1);setScore(player,"attack3",part[16]*1);setScore(player,"attack4",part[17]*1);if(part[18]!=="0"){player.addTag(part[18]);};setScore(player,`stg${selected+player.box}`,0);player.runCommand(`scoreboard players set @s stg${selected+player.box} 0`);player.removeTag(tag);}
    });}};break;
    case 1:{const form=new ActionFormData()
    player.getTags().forEach(tag=>{let part=tag.split("/");if(tag.startsWith("stg"+(selected+player.box)+"/")){form.title(`stg${part[2]}v${part[3]}`);}});
    form.body("serp.stg_release_body")
    form.button("serp.release_confirm","textures/stg/confirm")
    form.button("serp.release_decline","textures/stg/decline")
    form.show(player).then(result=>{
    let response=result.selection
    if(result.canceled){this.stg(player);}
    switch(response){
    case 0:{let nick="0";player.getTags().forEach(tag=>{if(tag.startsWith("stg"+(selected+player.box)+"/")){if(tag.split("/")[18]==="0"){nick=`entity.pokemon:p${getScore(`stg${selected+player.box}`,player)}.name`}else{nick=tag.split("/")[18].replace("nickname&","")}player.runCommand(`tellraw @s{"rawtext":[{"translate":"serp.goodbye_stg"},{"translate":"${nick}"},{"text":"!"}]}`);player.runCommand(`scoreboard players set @s stg${selected+player.box} 0`);player.removeTag(tag);}});};break;
    case 1:{this.stg(player)};break;
          }});
        };break;
        }
      });
    }else{this.stg(player);}
    }
    else if(selected===16){const form=new ActionFormData()
    form.title("main.stg")
    form.body("serp.change_box")
    for(var u=1;u<8;u++){form.button(`${u}`,"textures/stg/changebox")}
    form.show(player).then(result=>{
    let response=result.selection
    if(result.canceled){this.stg(player);}
    if(!result.canceled){player.box=((response)*15);this.stg(player);}});
        }
      });
    }
    store(player){
    const articles=[{id:["serp:pokeball"],icon:"pokeitems/items/poke/poke_ball",cost:200},{id:["serp:greatball"],icon:"pokeitems/items/poke/great_ball",cost:600},{id:["serp:ultraball"],icon:"pokeitems/items/poke/ultra_ball",cost:800},{id:["serp:diveball"],icon:"pokeitems/items/poke/dive_ball",cost:1000},{id:["serp:duskball"],icon:"pokeitems/items/poke/dusk_ball",cost:1000},{id:["serp:luxuryball"],icon:"pokeitems/items/poke/luxury_ball",cost:1000},{id:["serp:nestball"],icon:"pokeitems/items/poke/nest_ball",cost:1000},{id:["serp:netball"],icon:"pokeitems/items/poke/net_ball",cost:1000},{id:["serp:premierball"],icon:"pokeitems/items/poke/premier_ball",cost:1200},{id:["serp:timerball"],icon:"pokeitems/items/poke/timer_ball",cost:1000},{id:["serp:down_part"],icon:"pokeitems/items/poke/down_part",cost:150},{id:["serp:potion"],icon:"pokeitems/items/poke/potion",cost:200},{id:["serp:super_potion"],icon:"pokeitems/items/poke/super_potion",cost:400},{id:["serp:hyper_potion"],icon:"pokeitems/items/poke/hyper_potion",cost:800},{id:["serp:max_potion"],icon:"pokeitems/items/poke/max_potion",cost:1250},{id:["serp:full_restore"],icon:"pokeitems/items/poke/full_restore",cost:1500},{id:["serp:full_heal"],icon:"pokeitems/items/poke/full_heal",cost:400},{id:["serp:revive"],icon:"pokeitems/items/poke/revive",cost:750},{id:["serp:max_revive"],icon:"pokeitems/items/poke/max_revive",cost:2000},{id:["serp:fresh_water"],icon:"pokeitems/items/poke/fresh_water",cost:200},{id:["serp:soda_pop"],icon:"pokeitems/items/poke/soda_pop",cost:300},{id:["serp:lemonade"],icon:"pokeitems/items/poke/lemonade",cost:350},{id:["serp:moomoo_milk"],icon:"pokeitems/items/poke/moomoo_milk",cost:600,gen:2},{id:["serp:clefairy_plush"],icon:"pokeitems/items/poke/clefairy_plush",cost:1800,gen:1},{id:["serp:pichu_plush"],icon:"pokeitems/items/poke/pichu_plush",cost:1800,gen:2},{id:["serp:mulch"],icon:"pokeitems/items/poke/mulch",cost:150},{id:["serp:repel"],icon:"pokeitems/items/poke/repel",cost:400},{id:["serp:super_repel"],icon:"pokeitems/items/poke/super_repel",cost:700},{id:["serp:max_repel"],icon:"pokeitems/items/poke/max_repel",cost:900},{id:["serp:ash_helmet","serp:ash_chestplate","serp:ash_leggings","serp:ash_boots"],icon:"pokeitems/items/poke/ash_helmet",cost:3200},{id:["serp:red_helmet","serp:red_chestplate","serp:red_leggings","serp:red_boots"],icon:"pokeitems/items/poke/red_helmet",cost:3200},{id:["serp:green_helmet","serp:green_chestplate","serp:green_leggings","serp:green_boots"],icon:"pokeitems/items/poke/green_helmet",cost:3200},{id:["serp:rocket_helmet","serp:rocket_chestplate","serp:rocketm_leggings","serp:rocket_boots"],icon:"pokeitems/items/poke/rocketm_leggings",cost:3200},{id:["serp:rocket_helmet","serp:rocket_chestplate","serp:rocketf_leggings","serp:rocket_boots"],icon:"pokeitems/items/poke/rocketf_leggings",cost:3200}]
    const form=new ActionFormData();form.title(` ${getScore("money",player)}`);form.body(" ")
    for(const article of articles){form.button(` ${article.cost}`,`${article.icon}`);}
    form.show(player).then(result=>{let response=result.selection;
    if(result.canceled){player.playSound("serp.market.store");}else{for(const article of articles){
    if(articles.indexOf(article)==response&&(!article.gen)){if(getScore("money",player)>=article.cost){setScore(player,"money",(getScore("money",player)-article.cost));for(const unity of article.id){player.runCommand('tellraw @s {"rawtext":[{"translate":"store.buy"}]}');player.runCommand(`give @s ${unity}`);}}else{player.runCommand('tellraw @s {"rawtext":[{"translate":"store.dont_have_money"}]}');}}
    else if(articles.indexOf(article)==response&&article.gen){if(player.hasTag(`gen${article.gen}`)){if(getScore("money",player)>=article.cost){setScore(player,"money",(getScore("money",player)-article.cost));player.runCommand('tellraw @s {"rawtext":[{"translate":"store.buy"}]}');player.runCommand(`give @s ${article.id}`);}else{player.runCommand('tellraw @s {"rawtext":[{"translate":"store.dont_have_money"}]}');}}else{player.runCommand('tellraw @s {"rawtext":[{"translate":"store.dont_have_this"}]}');}}
      }}});
    }
    start1(player){
    const form=new ActionFormData();form.title("welcome.oak");form.body("serp.intro_start")
    form.button("serp.confirm","textures/ui/bubble_yes")
    form.show(player).then(result=>{
    if(result.canceled||!result.canceled){let v=0;let r=setScoreR(1,202);if(r>=1&&r<=160){v=1}else if(r>=161&&r<=200){v=2}else if(r==201){v=4}else if(r==202){v=5};setScore(player,"TrainerID",setScoreR(1000000,9999999));setScore(player,"ball",1);setScore(player,"variant",v);setScore(player,"subspc",0);setScore(player,"HPserpC",999);setScore(player,"condition",0);setScore(player,"amistadserp",25);setScore(player,"exp",250);setScore(player,"naturaleza",setScoreR(1,25));setScore(player,"ability",0);setScore(player,"item",0);setScore(player,"gigamaxf",0);setScore(player,"dynamaxl",0);setScore(player,"attack3",0);setScore(player,"attack4",0);this.generations(player);}
      });
    }
    start2(player){
    const form=new ActionFormData();form.title("welcome.oak");form.body("serp.intro_end")
    form.button("serp.confirm","textures/ui/bubble_yes")
    form.show(player).then(result=>{
    if(result.canceled||!result.canceled){setScore(player,"money",5000);setScore(player,"chips",100);player.runCommand('give @s compass 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}');player.runCommand("give @s serp:pokeball 15");player.runCommand("give @s serp:potion 10");player.addTag("pokedex");player.addTag("finished");}
      });
    }
    generations(player){let Stitle="null";let Sbody="null";let Sid=0;let Sattack1=0;let Sattack2=0;let Sgrowl="0";
    const starters1=[{button:0,icon:"textures/pokedex/dex.1",name:"entity.pokemon:p1.name",title:"dex.1t1_10t2_14",body:"bulbasaur.info",id:1,attack1:241,attack2:257,growl:"mob.pokemon.1"},{button:1,icon:"textures/pokedex/dex.4",name:"entity.pokemon:p4.name",title:"dex.4t1_00t2_07",body:"charmander.info",id:4,attack1:242,attack2:256,growl:"mob.pokemon.4"},{button:2,icon:"textures/pokedex/dex.7",name:"entity.pokemon:p7.name",title:"dex.7t1_00t2_18",body:"squirtle.info",id:7,attack1:242,attack2:256,growl:"mob.pokemon.7"},{button:3,icon:"textures/pokedex/dex.25",name:"entity.pokemon:p25.name",title:"dex.25t1_00t2_04",body:"pikachu.info",id:25,attack1:241,attack2:256,growl:"mob.pokemon.25"},{button:4,icon:"textures/pokedex/dex.133",name:"entity.pokemon:p133.name",title:"dex.133t1_00t2_13",body:"eevee.info",id:133,attack1:241,attack2:256,growl:"mob.pokemon.133"}]
    const starters2=[{button:0,icon:"textures/pokedex/dex.152",name:"entity.pokemon:p152.name",title:"dex.152t1_00t2_10",body:"chikorita.info",id:152,attack1:241,attack2:257,growl:"mob.pokemon.152"},{button:1,icon:"textures/pokedex/dex.155",name:"entity.pokemon:p155.name",title:"dex.155t1_00t2_07",body:"cyndaquil.info",id:155,attack1:241,attack2:257,growl:"mob.pokemon.155"},{button:2,icon:"textures/pokedex/dex.158",name:"entity.pokemon:p158.name",title:"dex.158t1_00t2_18",body:"totodile.info",id:158,attack1:242,attack2:256,growl:"mob.pokemon.158"}]
    const starters3=[{button:0,icon:"textures/pokedex/dex.252",name:"entity.pokemon:p252.name",title:"dex.252t1_00t2_10",body:"treecko.info",id:252,attack1:241,attack2:257,growl:"mob.pokemon.252"},{button:1,icon:"textures/pokedex/dex.255",name:"entity.pokemon:p255.name",title:"dex.255t1_00t2_07",body:"torchic.info",id:255,attack1:242,attack2:256,growl:"mob.pokemon.255"},{button:2,icon:"textures/pokedex/dex.258",name:"entity.pokemon:p258.name",title:"dex.258t1_00t2_18",body:"mudkip.info",id:258,attack1:241,attack2:257,growl:"mob.pokemon.258"}]
    let form=new ActionFormData();form.title("serp.choosing_gen");form.body("serp.gen_forget")
    form.button("Gen 1","pokeitems/items/poke/first_generation")
    form.button("Gen 2","pokeitems/items/poke/second_generation")
    form.button("Gen 3","pokeitems/items/poke/third_generation")
    form.show(player).then(result=>{
    let response=result.selection
    if(result.canceled){this.generations(player);}
    else{if(response==0){player.box=1;};if(response==1){player.box=2;};if(response==2){player.box=3;}
    let form=new ActionFormData();form.title("serp.choosing_poke");form.body("serp.gen_forget")
    if(player.box==1){for(const starter of starters1){form.button(`${starter.name}`,`${starter.icon}`)}}
    if(player.box==2){for(const starter of starters2){form.button(`${starter.name}`,`${starter.icon}`)}}
    if(player.box==3){for(const starter of starters3){form.button(`${starter.name}`,`${starter.icon}`)}}
    form.show(player).then(result=>{let response=result.selection
    if(result.canceled){this.generations(player);}
    else{
    if(player.box==1){for(const starter of starters1){if(starter.button==response){Stitle=starter.title;Sbody=starter.body;Sid=starter.id;Sattack1=starter.attack1;Sattack2=starter.attack2;Sgrowl=starter.growl;}}}
    if(player.box==2){for(const starter of starters2){if(starter.button==response){Stitle=starter.title;Sbody=starter.body;Sid=starter.id;Sattack1=starter.attack1;Sattack2=starter.attack2;Sgrowl=starter.growl;}}}
    if(player.box==3){for(const starter of starters3){if(starter.button==response){Stitle=starter.title;Sbody=starter.body;Sid=starter.id;Sattack1=starter.attack1;Sattack2=starter.attack2;Sgrowl=starter.growl;}}}
    let form=new ActionFormData();form.title(Stitle);form.body(Sbody)
    form.button("serp.confirm","textures/ui/bubble_yes");form.button("serp.cancel","textures/ui/bubble_no")
    form.show(player).then(result=>{let response=result.selection;
    if(result.canceled){this.generations(player);}
    switch(response){
    case 0:{setScore(player,"attack1",Sattack1);setScore(player,"attack2",Sattack2);setScore(player,"entityserp",Sid);player.playSound(Sgrowl);this.start2(player);};break;
    case 1:{this.generations(player);};break;
        }});
       }
      });
     }
    });
   }
  }
const forms=new gui();
async function bound(player){let owner=player.nameTag;let slot1="team1/0/0";let slot2="team2/0/0";let slot3="team3/0/0";let slot4="team4/0/0";let slot5="team5/0/0";let slot6="team6/0/0";
  Array.from(world.getDimension('overworld').getEntities()).forEach(entity=>{
  let nickname="0";if(entity.nameTag){entity.nickname="nickname&"+entity.nameTag;}else{entity.nickname="0"}
  if(entity.hasTag(`owner&${owner}&1`)){slot1=`team1/${getScore("ball",entity)}/${getScore("entityserp",entity)}/${getScore("variant",entity)}/${getScore("subspc",entity)}/${getScore("HPserpC",entity)}/${getScore("condition",entity)}/${getScore("amistadserp",entity)}/${getScore("exp",entity)}/${getScore("naturaleza",entity)}/${getScore("ability",entity)}/${getScore("item",entity)}/${getScore("gigamaxf",entity)}/${getScore("dynamaxl",entity)}/${getScore("attack1",entity)}/${getScore("attack2",entity)}/${getScore("attack3",entity)}/${getScore("attack4",entity)}/${entity.nickname}`;}
  if(entity.hasTag(`owner&${owner}&2`)){slot2=`team2/${getScore("ball",entity)}/${getScore("entityserp",entity)}/${getScore("variant",entity)}/${getScore("subspc",entity)}/${getScore("HPserpC",entity)}/${getScore("condition",entity)}/${getScore("amistadserp",entity)}/${getScore("exp",entity)}/${getScore("naturaleza",entity)}/${getScore("ability",entity)}/${getScore("item",entity)}/${getScore("gigamaxf",entity)}/${getScore("dynamaxl",entity)}/${getScore("attack1",entity)}/${getScore("attack2",entity)}/${getScore("attack3",entity)}/${getScore("attack4",entity)}/${entity.nickname}`;}
  if(entity.hasTag(`owner&${owner}&3`)){slot3=`team3/${getScore("ball",entity)}/${getScore("entityserp",entity)}/${getScore("variant",entity)}/${getScore("subspc",entity)}/${getScore("HPserpC",entity)}/${getScore("condition",entity)}/${getScore("amistadserp",entity)}/${getScore("exp",entity)}/${getScore("naturaleza",entity)}/${getScore("ability",entity)}/${getScore("item",entity)}/${getScore("gigamaxf",entity)}/${getScore("dynamaxl",entity)}/${getScore("attack1",entity)}/${getScore("attack2",entity)}/${getScore("attack3",entity)}/${getScore("attack4",entity)}/${entity.nickname}`;}
  if(entity.hasTag(`owner&${owner}&4`)){slot4=`team4/${getScore("ball",entity)}/${getScore("entityserp",entity)}/${getScore("variant",entity)}/${getScore("subspc",entity)}/${getScore("HPserpC",entity)}/${getScore("condition",entity)}/${getScore("amistadserp",entity)}/${getScore("exp",entity)}/${getScore("naturaleza",entity)}/${getScore("ability",entity)}/${getScore("item",entity)}/${getScore("gigamaxf",entity)}/${getScore("dynamaxl",entity)}/${getScore("attack1",entity)}/${getScore("attack2",entity)}/${getScore("attack3",entity)}/${getScore("attack4",entity)}/${entity.nickname}`;}
  if(entity.hasTag(`owner&${owner}&5`)){slot5=`team5/${getScore("ball",entity)}/${getScore("entityserp",entity)}/${getScore("variant",entity)}/${getScore("subspc",entity)}/${getScore("HPserpC",entity)}/${getScore("condition",entity)}/${getScore("amistadserp",entity)}/${getScore("exp",entity)}/${getScore("naturaleza",entity)}/${getScore("ability",entity)}/${getScore("item",entity)}/${getScore("gigamaxf",entity)}/${getScore("dynamaxl",entity)}/${getScore("attack1",entity)}/${getScore("attack2",entity)}/${getScore("attack3",entity)}/${getScore("attack4",entity)}/${entity.nickname}`;}
  if(entity.hasTag(`owner&${owner}&6`)){slot6=`team6/${getScore("ball",entity)}/${getScore("entityserp",entity)}/${getScore("variant",entity)}/${getScore("subspc",entity)}/${getScore("HPserpC",entity)}/${getScore("condition",entity)}/${getScore("amistadserp",entity)}/${getScore("exp",entity)}/${getScore("naturaleza",entity)}/${getScore("ability",entity)}/${getScore("item",entity)}/${getScore("gigamaxf",entity)}/${getScore("dynamaxl",entity)}/${getScore("attack1",entity)}/${getScore("attack2",entity)}/${getScore("attack3",entity)}/${getScore("attack4",entity)}/${entity.nickname}`;}
  });
  player.getTags().forEach(tag=>{
  if(tag.startsWith("out_slot")){let slot=tag.replace("out_slot","");try{player.runCommand(`execute as @s unless entity @e[tag="owner&${owner}&${slot}",r=20] run tag @s add return${slot}`);}catch{}}
  if(tag.includes("return")){const returned=tag.replace('return','');player.runCommand(`execute as @s anchored eyes run particle serp:back_player ^^^0.5`);player.runCommand(`execute at @e[family=pokemon,tag="owner&${owner}&${returned}"] run particle serp:back ~~~`);player.runCommand(`event entity @e[family=pokemon,tag="owner&${owner}&${returned}"] serp:despawn`);player.playSound("serp.pokeball.enter");player.removeTag(`out_slot${returned}`);player.removeTag(`return${returned}`);}
  if(tag.startsWith("team")&&(!player.hasTag("return1")&&!player.hasTag("return2")&&!player.hasTag("return3")&&!player.hasTag("return4")&&!player.hasTag("return5")&&!player.hasTag("return6"))&&(tag.split("/")[2]==="0"||tag.includes("undefined")||(!tag.includes("/")))){try{setScore(player,`team${tag.split("/")[0].replace("team","")}`,0);}catch{}player.removeTag(tag);}
  for(var u=1;u<=6;u++){if(tag.startsWith(`team${u}`)){setScore(player,`team${u}`,tag.split("/")[2]*1)}if(tag.startsWith(`team${u}`)&&(((!player.hasTag("gen1"))&&getScore(`team${u}`,player)>0&&getScore(`team${u}`,player)<=151)||((!player.hasTag("gen2"))&&getScore(`team${u}`,player)>151&&getScore(`team${u}`,player)<=251)||((!player.hasTag("gen3"))&&getScore(`team${u}`,player)>251&&getScore(`team${u}`,player)<=386))){setScore(player,`team${u}`,0);player.removeTag(tag);}}
  });
  player.getTags().forEach(tag=>{if(!player.hasTag("to_stg")){
  if(tag.startsWith("team1")&&player.hasTag("out_slot1")&&(!player.hasTag("return1"))&&tag!==slot1){player.removeTag(tag);player.addTag(slot1);}
  if(tag.startsWith("team2")&&player.hasTag("out_slot2")&&(!player.hasTag("return2"))&&tag!==slot2){player.removeTag(tag);player.addTag(slot2);}
  if(tag.startsWith("team3")&&player.hasTag("out_slot3")&&(!player.hasTag("return3"))&&tag!==slot3){player.removeTag(tag);player.addTag(slot3);}
  if(tag.startsWith("team4")&&player.hasTag("out_slot4")&&(!player.hasTag("return4"))&&tag!==slot4){player.removeTag(tag);player.addTag(slot4);}
  if(tag.startsWith("team5")&&player.hasTag("out_slot5")&&(!player.hasTag("return5"))&&tag!==slot5){player.removeTag(tag);player.addTag(slot5);}
  if(tag.startsWith("team6")&&player.hasTag("out_slot6")&&(!player.hasTag("return6"))&&tag!==slot6){player.removeTag(tag);player.addTag(slot6);}
  }});
  }
async function getPokemon(player){let nick="0";let nn=`entity.pokemon:p${getScore("entityserp",player)}.name`;player.getTags().forEach(tag=>{if(tag.startsWith("nickname&")){nick=tag;nn=tag.replace("nickname&","")}});
  for(var u=1;u<=6;u++){if(((!player.hasTag("gen1"))&&getScore("entityserp",player)>0&&getScore("entityserp",player)<=151)||((!player.hasTag("gen2"))&&getScore("entityserp",player)>151&&getScore("entityserp",player)<=251)||((!player.hasTag("gen3"))&&getScore("entityserp",player)>251&&getScore("entityserp",player)<=386)){setScore(player,"entityserp",0);}}
  for(var u=1;u<=111;u++){
  if((u>=1&&u<=6)&&getScore("entityserp",player)>0&&!player.hasTag("to_stg")){try{if(getScore(`team${u}`,player)==0){player.runCommand(`tellraw @s{"rawtext":[{"translate":"serp.welcome_back"},{"translate":"${nn}"},{"text":"!"}]}`);player.addTag(`team${u}/${getScore("ball",player)}/${getScore("entityserp",player)}/${getScore("variant",player)}/${getScore("subspc",player)}/${getScore("HPserpC",player)}/${getScore("condition",player)}/${getScore("amistadserp",player)}/${getScore("exp",player)}/${getScore("naturaleza",player)}/${getScore("ability",player)}/${getScore("item",player)}/${getScore("gigamaxf",player)}/${getScore("dynamaxl",player)}/${getScore("attack1",player)}/${getScore("attack2",player)}/${getScore("attack3",player)}/${getScore("attack4",player)}/${nick}`);setScore(player,`team${u}`,getScore("entityserp",player));setScore(player,"entityserp",0);player.getTags().forEach(tag=>{if(tag.startsWith("nickname&")){player.removeTag(tag);}});}}catch{}}
  else if((u>=7&&u<=111)&&(player.hasTag("to_stg")||(getScore("team1",player)>0&&getScore("entityserp",player)>0&&getScore("team2",player)>0&&getScore("team3",player)>0&&getScore("team4",player)>0&&getScore("team5",player)>0&&getScore("team6",player)>0))){try{if(getScore(`stg${u-6}`,player)==0){player.runCommand(`tellraw @s{"rawtext":[{"translate":"${nn}"},{"translate":"ball.pc"}]}`);player.addTag(`stg${u-6}/${getScore("ball",player)}/${getScore("entityserp",player)}/${getScore("variant",player)}/${getScore("subspc",player)}/${getScore("HPserpC",player)}/${getScore("condition",player)}/${getScore("amistadserp",player)}/${getScore("exp",player)}/${getScore("naturaleza",player)}/${getScore("ability",player)}/${getScore("item",player)}/${getScore("gigamaxf",player)}/${getScore("dynamaxl",player)}/${getScore("attack1",player)}/${getScore("attack2",player)}/${getScore("attack3",player)}/${getScore("attack4",player)}/${nick}`);setScore(player,`stg${u-6}`,getScore("entityserp",player));setScore(player,"entityserp",0);player.getTags().forEach(tag=>{if(tag.startsWith("nickname&")){player.removeTag(tag);}});if(player.hasTag("to_stg")){player.removeTag("to_stg");}}}catch{}}
}}
async function slotc(player){let item=player.getComponent("inventory").container.getItem(player.selectedSlot);
if(item.typeId==="minecraft:compass"&&player.isSneaking&&(!player.hasTag("summary")&&!player.hasTag("evolve"))){
setScore(player,"CombatRandom",0,"add");if(getScore("CombatRandom",player)<=0){player.runCommand("scoreboard players set @s CombatRandom 12");}
if(getScore("CombatRandom",player)==6){player.runCommand("titleraw @s times 0 0 0");player.runCommand("function spawn/change_slot_team");let s="0";let b="0";let sp="0";let v="0";let e="0";let c="0";let i="0";let nick="entity.pokemon:p0.name";let hpstatus="equippable.0";player.getTags().forEach(tag=>{if(tag.includes("use_slot")){s=tag.replace("use_slot","");}});player.getTags().forEach(tag=>{if(tag.startsWith(`team${s}`)){let p=tag.split("/");b=p[1];sp=p[2];v=p[3];c=p[6];e=Math.floor(p[8]/50);i=p[11];if(p[18]!=="0"){nick=p[18].replace("nickname&","");}else{nick=`entity.pokemon:p${sp}.name`};if(p[5]>1){hpstatus="serp.healthy"}else if(p[5]==1){hpstatus="serp.defeated"}}});player.runCommand('titleraw @s subtitle {"rawtext":[{"translate":"'+nick+'"},{"text":" "},{"translate":"serp.level"},{"text":"'+e+'"},{"text":"\n"},{"translate":"'+hpstatus+'"},{"translate":"condition.'+c+'"},{"text":"\n"},{"translate":"serp.item"},{"translate":"equippable.'+i+'"}]}');player.runCommand('titleraw @s title {"rawtext":[{"text":"s'+sp+'v'+v+'"}]}');player.runCommand(`titleraw @s actionbar {"rawtext":[{"text":"§0poke${s}${b}"}]}`);player.playSound("serp.pokedex");player.runCommand("titleraw @s reset");}if(getScore("CombatRandom",player)>0){player.runCommand("scoreboard players remove @s CombatRandom 1");}
}}
async function battle(entity){if(entity.typeId.startsWith("pokemon:")&&entity.hasTag("battle")&&entity.hasTag("battle2")&&getScore('VIC',entity)>0&&getScore('attackactive',entity)>0&&getScore('battledelay',entity)==0){let hp=entity.getComponent("minecraft:health");
if((entity.hasTag("turn1")&&getScore("CombatTimer",entity)==2)||(entity.hasTag("turn2")&&getScore("CombatTimer",entity)==3)){entity.runCommand("function battle/serpbattle/activate");entity.runCommand(`function pokemon/${entity.typeId.replace("pokemon:p","")}`);}
if(getScore("CombatTimer",entity)==4){entity.runCommand("function battle/serpbattle/battle1");}
if((entity.hasTag("turn1")&&getScore('CombatTimer',entity)==10)||(entity.hasTag("turn2")&&getScore('CombatTimer',entity)==10)){entity.runCommand("function battle/serpbattle/battle2");}
if((entity.hasTag("turn1")&&getScore('CombatTimer',entity)==5)||(entity.hasTag("turn2")&&getScore('CombatTimer',entity)==25)){entity.runCommand(`tellraw @a[r=16,tag=!hide_txt]{"rawtext":[{"text":"§e"},{"selector":"@s"},{"translate":"combat.level"},{"text":"${Math.floor(getScore('exp',entity)/50)} "},{"translate":"combat.used"},{"translate":"attack.${getScore('attackactive',entity)}"},{"text":"!§r"}]}`);}
if((entity.hasTag("turn1")&&getScore('CombatTimer',entity)>=5&&getScore('CombatTimer',entity)<=20)||(entity.hasTag("turn2")&&getScore('CombatTimer',entity)>=25&&getScore('CombatTimer',entity)<=40)){entity.runCommand("function battle/serpbattle/attackanimation");}
if((entity.hasTag("turn1")&&getScore('CombatTimer',entity)==41)||(entity.hasTag("turn2")&&getScore('CombatTimer',entity)==21)){entity.runCommand("function battle/serpbattle/damage");entity.runCommand(`tp @s ~~0.2~ facing @e[rm=0.2,scores={VIC=${getScore("VIC",entity)}}] false`);}
if((entity.hasTag("turn1")&&getScore('CombatTimer',entity)==22)||(entity.hasTag("turn2")&&getScore('CombatTimer',entity)==42)){entity.runCommand("function battle/serpbattle/damage_txt");}
if((entity.hasTag("turn1")&&getScore('CombatTimer',entity)==23)||(entity.hasTag("turn2")&&getScore('CombatTimer',entity)==43)){entity.runCommand("function battle/serpbattle/conditionbattle");}
if(getScore('CombatTimer',entity)>=50){entity.runCommand("function battle/serpbattle/StopTurn");}
}}
async function battle2(entity){if(entity.typeId.startsWith("pokemon:")&&entity.hasTag("battle")&&entity.hasTag("battle2")&&getScore('VIC',entity)>0&&getScore('attackactive',entity)>0&&getScore('battledelay',entity)==0){let hp=entity.getComponent("minecraft:health");
if((entity.hasTag("turn1")&&getScore("CombatTimer",entity)==2)||(entity.hasTag("turn2")&&getScore("CombatTimer",entity)==3)){entity.runCommand("function battle/serpbattle/activate");}
if(getScore("CombatTimer",entity)==4){entity.runCommand("function battle/serpbattle/battle1");}
if((entity.hasTag("turn1")&&getScore('CombatTimer',entity)==10)||(entity.hasTag("turn2")&&getScore('CombatTimer',entity)==10)){entity.runCommand("function battle/serpbattle/battle2");}
if((entity.hasTag("turn1")&&getScore('CombatTimer',entity)==5)||(entity.hasTag("turn2")&&getScore('CombatTimer',entity)==25)){entity.runCommand(`tellraw @a[r=16,tag=!hide_txt]{"rawtext":[{"text":"§e"},{"selector":"@s"},{"translate":"combat.level"},{"text":"${Math.floor(getScore('exp',entity)/50)} "},{"translate":"combat.used"},{"translate":"attack.${getScore('attackactive',entity)}"},{"text":"!§r"}]}`);}
if((entity.hasTag("turn1")&&getScore('CombatTimer',entity)>=5&&getScore('CombatTimer',entity)<=20)||(entity.hasTag("turn2")&&getScore('CombatTimer',entity)>=25&&getScore('CombatTimer',entity)<=40)){entity.runCommand("function battle/serpbattle/attackanimation");}
if((entity.hasTag("turn1")&&getScore('CombatTimer',entity)==41)||(entity.hasTag("turn2")&&getScore('CombatTimer',entity)==21)){for(const attack of attacks){if(getScore("attackactive")==attack.Aid){
if(entity.hasTag("turn1")){}
if(attack.effect){if(attack.effect==191){hp.setCurrentValue()}}
}}}
if((entity.hasTag("turn1")&&getScore('CombatTimer',entity)==22)||(entity.hasTag("turn2")&&getScore('CombatTimer',entity)==42)){entity.runCommand("function battle/serpbattle/damage_txt");}
if((entity.hasTag("turn1")&&getScore('CombatTimer',entity)==23)||(entity.hasTag("turn2")&&getScore('CombatTimer',entity)==43)){entity.runCommand("function battle/serpbattle/conditionbattle");}
if(getScore('CombatTimer',entity)>=50){entity.runCommand("function battle/serpbattle/StopTurn");}
}}